import { FILLER_WORDS, MISTAKE_PATTERNS } from "./constants";
import {
  AnswerSubmission,
  Dimension,
  DetectedMistake,
  FeedbackReport,
  Level,
  Question,
  Skill,
} from "./types";

/**
 * ---------------------------------------------------------------------------
 * MOCK AI LAYER
 * ---------------------------------------------------------------------------
 * Everything in this file simulates what a real LLM-backed evaluation
 * service would return. Every function is deliberately pure (input -> output,
 * no network calls) so it can be swapped for a real API call later — e.g.
 * `analyzeTextResponse` could become `await fetch("/api/ai/analyze", ...)`
 * without any component needing to change, since the return shape
 * (FeedbackReport / DetectedMistake) stays the same.
 */

const uid = () => Math.random().toString(36).slice(2, 10);

// ---- Text analysis -------------------------------------------------------

interface TextAnalysis {
  score: number;
  mistakes: DetectedMistake[];
  fillerCount: number;
  wordCount: number;
  sentenceCount: number;
  vocabDiversity: number; // 0-1
}

export function analyzeTextResponse(text: string, skill: Skill): TextAnalysis {
  const trimmed = text.trim();
  const words = trimmed.length ? trimmed.split(/\s+/) : [];
  const wordCount = words.length;
  const sentenceCount = Math.max(1, (trimmed.match(/[.!?]+/g) || []).length);
  const uniqueWords = new Set(words.map((w) => w.toLowerCase().replace(/[^a-z']/g, "")));
  const vocabDiversity = wordCount > 0 ? uniqueWords.size / wordCount : 0;

  let fillerCount = 0;
  if (skill === "speaking") {
    for (const filler of FILLER_WORDS) {
      const re = new RegExp(`\\b${filler.replace(/\s+/g, "\\s+")}\\b`, "gi");
      const matches = trimmed.match(re);
      if (matches) fillerCount += matches.length;
    }
  }

  const mistakes: DetectedMistake[] = [];
  for (const pattern of MISTAKE_PATTERNS) {
    const match = trimmed.match(pattern.regex);
    if (match) {
      mistakes.push({
        id: uid(),
        category: pattern.category,
        dimension: pattern.dimension,
        original: match[0],
        correction: pattern.correction(match),
        why: pattern.why,
      });
    }
  }

  let score = 50;

  if (wordCount === 0) {
    return { score: 0, mistakes, fillerCount, wordCount, sentenceCount, vocabDiversity };
  }

  score += Math.min(20, Math.round((wordCount / 45) * 20));
  score += Math.round(vocabDiversity * 20);
  score -= mistakes.length * 8;
  score -= fillerCount * 4;
  if (sentenceCount >= 2) score += 5;

  score = Math.max(5, Math.min(98, Math.round(score)));

  return { score, mistakes, fillerCount, wordCount, sentenceCount, vocabDiversity };
}

// ---- MCQ scoring -----------------------------------------------------------

export function scoreMcq(question: Question, selectedOptionId?: string): boolean {
  return !!selectedOptionId && selectedOptionId === question.correctOptionId;
}

// ---- 5-layer feedback report ----------------------------------------------

export function buildFeedbackReport(
  question: Question,
  submission: AnswerSubmission
): FeedbackReport {
  if (question.type === "mcq" || question.type === "reading" || question.type === "listening") {
    const correct = scoreMcq(question, submission.selectedOptionId);
    const chosen = question.options?.find((o) => o.id === submission.selectedOptionId);
    const right = question.options?.find((o) => o.id === question.correctOptionId);
    return {
      questionId: question.id,
      skill: question.skill,
      dimensions: question.dimensions,
      score: correct ? 100 : 20,
      whatYouDid: chosen
        ? `You selected: "${chosen.text}"`
        : "You did not select an answer.",
      whatWentWrong: correct
        ? "Nothing — this is the correct interpretation."
        : `The correct answer was "${right?.text ?? "—"}".`,
      whyItsWrong: correct
        ? "Your answer matches the key detail / inference the passage supports."
        : "Your answer overlooks a detail stated (or implied) directly in the passage.",
      howToImprove: correct
        ? "Keep listening/reading for the specific detail the question is targeting, not just the general topic."
        : "Re-read or re-listen to the passage focusing only on the question being asked, and eliminate options that contradict it.",
      practiceAgain: "Try a similar passage and pause after each sentence to summarize it in your head.",
      mistakes: [],
      strengths: correct ? ["Correctly identified the key detail"] : [],
    };
  }

  // writing / speaking — free text analysis
  const text = submission.textResponse ?? "";
  const analysis = analyzeTextResponse(text, question.skill);

  const strengths: string[] = [];
  if (analysis.wordCount >= 25) strengths.push("Good level of detail / effort");
  if (analysis.vocabDiversity > 0.6) strengths.push("Good vocabulary range");
  if (analysis.mistakes.length === 0) strengths.push("No major grammar issues detected");
  if (question.skill === "speaking" && analysis.fillerCount === 0) {
    strengths.push("No filler words detected");
  }

  const topMistake = analysis.mistakes[0];
  const fillerNote =
    question.skill === "speaking" && analysis.fillerCount > 0
      ? ` Also detected ${analysis.fillerCount} filler word${analysis.fillerCount > 1 ? "s" : ""} (e.g. "like", "umm").`
      : "";

  const whatWentWrong = topMistake
    ? `${topMistake.category}: "${topMistake.original}"${fillerNote}`
    : analysis.wordCount === 0
      ? "No response was submitted."
      : `Nothing major detected.${fillerNote}`;

  const whyItsWrong = topMistake
    ? topMistake.why
    : analysis.wordCount === 0
      ? "An empty response can't be evaluated against the rubric."
      : "This response is largely clean — see the improvement tip for a smaller refinement.";

  const howToImprove = topMistake
    ? `Replace "${topMistake.original}" with "${topMistake.correction}".`
    : question.skill === "speaking" && analysis.fillerCount > 0
      ? "Pause for 1-2 seconds instead of using a filler word when you need a moment to think."
      : analysis.wordCount < 20
        ? "Add more detail — aim for at least 2-3 full sentences to fully answer the prompt."
        : "Try varying your sentence openings to make the response feel less repetitive.";

  const practiceAgain = topMistake
    ? `Rewrite the sentence "${topMistake.original}" using the correction above, then say/write one more sentence using the same structure correctly.`
    : question.skill === "speaking"
      ? "Try a 60-second impromptu response to a new topic, focusing on removing filler words."
      : "Rewrite your response once more, aiming for a slightly more formal, structured tone.";

  return {
    questionId: question.id,
    skill: question.skill,
    dimensions: question.dimensions,
    score: analysis.score,
    whatYouDid: analysis.wordCount
      ? `You wrote ${analysis.wordCount} words across ${analysis.sentenceCount} sentence${analysis.sentenceCount > 1 ? "s" : ""}.`
      : "You did not submit a response.",
    whatWentWrong,
    whyItsWrong,
    howToImprove,
    practiceAgain,
    mistakes: analysis.mistakes,
    strengths,
  };
}

// ---- Level placement --------------------------------------------------------

export function deriveLevelFromScore(score: number): Level {
  if (score < 40) return "foundation";
  if (score < 65) return "development";
  if (score < 85) return "professional";
  return "mastery";
}

export function aggregateScores(scores: number[]): number {
  if (scores.length === 0) return 0;
  return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
}

export function scoreSubmission(question: Question, submission: AnswerSubmission): number {
  if (question.type === "mcq" || question.type === "reading" || question.type === "listening") {
    return scoreMcq(question, submission.selectedOptionId) ? 100 : 20;
  }
  return analyzeTextResponse(submission.textResponse ?? "", question.skill).score;
}

// ---- Dimension roll-up -------------------------------------------------------

/**
 * Given a set of scored questions, averages scores per supporting dimension
 * so the profile-wide dimension breakdown can be updated. A question tagged
 * with multiple dimensions contributes its score to each of them.
 */
export function aggregateDimensionScores(
  items: { question: Question; score: number }[]
): Partial<Record<Dimension, number>> {
  const buckets = new Map<Dimension, number[]>();
  for (const { question, score } of items) {
    for (const dim of question.dimensions) {
      if (!buckets.has(dim)) buckets.set(dim, []);
      buckets.get(dim)!.push(score);
    }
  }
  const result: Partial<Record<Dimension, number>> = {};
  for (const [dim, scores] of buckets.entries()) {
    result[dim] = aggregateScores(scores);
  }
  return result;
}
