import { Dimension, DIMENSIONS, Level, LEVELS, Skill, SkillStatus } from "./types";

export { LEVELS, DIMENSIONS };

export const SKILL_META: Record<
  Skill,
  { label: string; icon: string; description: string; color: string }
> = {
  listening: {
    label: "Listening",
    icon: "🎧",
    description: "Comprehension, context, tone and intent recognition.",
    color: "#3b82f6",
  },
  speaking: {
    label: "Speaking",
    icon: "🎙️",
    description: "Fluency, pronunciation, confidence and delivery.",
    color: "#f97316",
  },
  reading: {
    label: "Reading",
    icon: "📖",
    description: "Comprehension, inference and critical reading.",
    color: "#8b5cf6",
  },
  writing: {
    label: "Writing",
    icon: "✍️",
    description: "Structure, tone and professional writing.",
    color: "#0ea5e9",
  },
};

// Supporting dimensions — the lenses used to score every LSRW response.
// These are NOT independently gated skills; they roll up into whichever
// skill the question belonged to, and every skill draws on a relevant
// subset of them (see SKILL_DIMENSIONS below).
export const DIMENSION_META: Record<Dimension, { label: string; icon: string; description: string }> = {
  grammar: { label: "Grammar", icon: "🧩", description: "Sentence structure, tenses, articles, agreement." },
  vocabulary: { label: "Vocabulary", icon: "🗂️", description: "Word range, contextual usage, precision." },
  pronunciation: { label: "Pronunciation", icon: "🔊", description: "Clarity of individual sounds and words." },
  fluency: { label: "Fluency", icon: "💬", description: "Flow, pacing, and freedom from filler words." },
  comprehension: { label: "Comprehension", icon: "🧠", description: "Understanding what was heard or read." },
  sentenceConstruction: {
    label: "Sentence Construction",
    icon: "🏗️",
    description: "Building clear, well-formed sentences.",
  },
  professionalCommunication: {
    label: "Professional Communication",
    icon: "💼",
    description: "Workplace-appropriate structure and etiquette.",
  },
  confidence: { label: "Confidence", icon: "🌟", description: "Assurance and steadiness in delivery." },
  tone: { label: "Tone", icon: "🎭", description: "Matching register and attitude to the situation." },
  criticalThinking: {
    label: "Critical Thinking",
    icon: "🔍",
    description: "Inference, evaluating evidence, spotting assumptions.",
  },
  workplaceCommunication: {
    label: "Workplace Communication",
    icon: "🏢",
    description: "Real workplace scenarios — meetings, clients, teams.",
  },
};

// Which supporting dimensions are relevant to each skill. Drives the
// "Modules" list shown on each skill+level detail screen.
export const SKILL_DIMENSIONS: Record<Skill, Dimension[]> = {
  listening: ["comprehension", "criticalThinking", "tone", "workplaceCommunication"],
  speaking: ["fluency", "pronunciation", "confidence", "sentenceConstruction", "workplaceCommunication"],
  reading: ["comprehension", "vocabulary", "criticalThinking", "workplaceCommunication"],
  writing: ["grammar", "sentenceConstruction", "vocabulary", "professionalCommunication", "tone"],
};

export const LEVEL_META: Record<
  Level,
  { label: string; order: number; passThreshold: number; icon: string }
> = {
  foundation: { label: "Foundation", order: 0, passThreshold: 60, icon: "🌱" },
  development: { label: "Development", order: 1, passThreshold: 65, icon: "🧱" },
  professional: { label: "Professional", order: 2, passThreshold: 70, icon: "💼" },
  mastery: { label: "Mastery", order: 3, passThreshold: 75, icon: "🏆" },
};

// Short skill+level description shown at the top of the level detail screen,
// mirroring the "Understand core concepts of process automation..." pattern.
export const LEVEL_DESCRIPTIONS: Record<Skill, Record<Level, string>> = {
  listening: {
    foundation: "Follow simple instructions and identify the main idea in short audio clips.",
    development: "Understand full conversations, multi-step instructions and context.",
    professional: "Pick up implied meaning, tone and nuance in professional discussions.",
    mastery: "Handle negotiation, leadership and client conversations with precision.",
  },
  speaking: {
    foundation: "Introduce yourself and speak in simple, confident sentences.",
    development: "Describe situations, share opinions and speak fluently on the spot.",
    professional: "Present, debate and persuade in professional settings.",
    mastery: "Lead, negotiate and communicate with clients and executives.",
  },
  reading: {
    foundation: "Understand short passages and everyday vocabulary.",
    development: "Read workplace emails, articles and instructions with inference.",
    professional: "Critically read business reports and case studies.",
    mastery: "Evaluate research, spot assumptions, and read at an executive level.",
  },
  writing: {
    foundation: "Write clear, grammatically correct sentences and short paragraphs.",
    development: "Write professional emails and structured short messages.",
    professional: "Write reports, proposals and persuasive professional documents.",
    mastery: "Write executive summaries and strategic, high-stakes communication.",
  },
};

export function passThresholdFor(level: Level): number {
  return LEVEL_META[level].passThreshold;
}

export function statusForScore(score: number): SkillStatus {
  if (score >= 85) return "mastered";
  if (score >= 60) return "proficient";
  return "developing";
}

export const STATUS_META: Record<SkillStatus, { label: string; color: string; dot: string }> = {
  developing: { label: "Developing", color: "text-developing", dot: "bg-developing" },
  proficient: { label: "Proficient", color: "text-proficient", dot: "bg-proficient" },
  mastered: { label: "Mastered", color: "text-mastered", dot: "bg-mastered" },
};

// XP rewards — lightweight gamification matching the app's existing pattern
// of "+20 XP" per module and a fixed reward per level assessment.
export const XP = {
  perModule: 15,
  capstone: 25,
  levelAssessmentPass: 30,
};

export const FILLER_WORDS = ["like", "umm", "uh", "you know", "basically", "actually", "so yeah"];

export interface MistakePattern {
  regex: RegExp;
  category: string;
  dimension: Dimension;
  correction: (match: RegExpMatchArray) => string;
  why: string;
}

// Small curated pattern bank used by the mock AI grammar/tone checker.
// Each pattern is intentionally simple (regex + fix) so it's easy to extend.
export const MISTAKE_PATTERNS: MistakePattern[] = [
  {
    regex: /\bdiscuss about\b/i,
    category: "Preposition usage",
    dimension: "grammar",
    correction: () => "discuss",
    why: '"Discuss" is already transitive — it does not take "about" before its object.',
  },
  {
    regex: /\bwill not able\b/i,
    category: "Modal + verb form",
    dimension: "grammar",
    correction: () => "will not be able",
    why: 'The modal "will" needs "be" before the adjective "able".',
  },
  {
    regex: /\bI am having (a |some )?[a-z ]*\b(problem|work|meeting|issue|call)/i,
    category: "Stative verb usage",
    dimension: "grammar",
    correction: (m) => `I have ${m[1] ?? "a "}${m[2]}`,
    why: '"Have" (not the continuous "am having") is used for possession, plans and states.',
  },
  {
    regex: /\bhe don't\b/i,
    category: "Subject-verb agreement",
    dimension: "grammar",
    correction: () => "he doesn't",
    why: 'Third-person singular subjects ("he/she/it") take "doesn\'t", not "don\'t".',
  },
  {
    regex: /\bsince (two|three|four|five|\d+) (years|months|weeks)\b/i,
    category: "Preposition of duration",
    dimension: "grammar",
    correction: (m) => `for ${m[1]} ${m[2]}`,
    why: '"Since" is used with a starting point in time; "for" is used with a duration.',
  },
  {
    regex: /\bworking in ([a-z]+) company\b/i,
    category: "Article usage",
    dimension: "grammar",
    correction: (m) => `working in a ${m[1]} company`,
    why: "Singular countable nouns like \"company\" need an article (a/an/the).",
  },
  {
    regex: /\bkindly do the needful\b/i,
    category: "Tone / register",
    dimension: "tone",
    correction: () => "please take the necessary action",
    why: 'This phrase reads as dated / overly indirect in modern professional English.',
  },
  {
    regex: /\bi want to inform you that i will not able\b/i,
    category: "Formal register",
    dimension: "professionalCommunication",
    correction: () => "I would like to inform you that I will not be able",
    why: '"I would like to" is softer and more professional than "I want to" in formal writing.',
  },
  {
    regex: /\breturn back\b/i,
    category: "Redundancy",
    dimension: "sentenceConstruction",
    correction: () => "return",
    why: '"Return" already means "go back" — adding "back" is redundant.',
  },
  {
    regex: /\bmuch (more|less) better\b/i,
    category: "Comparative form",
    dimension: "grammar",
    correction: () => "much better",
    why: '"Better" is already comparative; it should not be doubled with "more/less".',
  },
];
