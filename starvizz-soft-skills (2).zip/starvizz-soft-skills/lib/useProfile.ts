"use client";

import { useCallback, useEffect, useState } from "react";
import {
  loadProfile,
  saveProfile,
  resetProfile as resetProfileStorage,
} from "./storage";
import { UserProfile } from "./types";

/**
 * Thin client-side hook around the localStorage-backed profile.
 * Swapping this for a real backend later means changing loadProfile /
 * saveProfile in storage.ts to hit an API instead — this hook (and every
 * component using it) stays the same.
 */
export function useProfile() {
  const [profile, setProfileState] = useState<UserProfile | null>(null);

  useEffect(() => {
    setProfileState(loadProfile());
  }, []);

  const setProfile = useCallback((updater: UserProfile | ((prev: UserProfile) => UserProfile)) => {
    setProfileState((prev) => {
      const base = prev ?? loadProfile();
      const next = typeof updater === "function" ? (updater as (p: UserProfile) => UserProfile)(base) : updater;
      saveProfile(next);
      return next;
    });
  }, []);

  const resetProfile = useCallback(() => {
    const fresh = resetProfileStorage();
    setProfileState(fresh);
  }, []);

  return {
    profile,
    isLoaded: profile !== null,
    setProfile,
    resetProfile,
  };
}
