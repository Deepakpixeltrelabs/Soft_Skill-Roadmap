import { DIMENSIONS, LEVELS, passThresholdFor, statusForScore, XP } from "./constants";
import {
  ActivityLogEntry,
  Certificate,
  Dimension,
  DetectedMistake,
  Level,
  LevelAssessmentResult,
  MistakeEntry,
  Skill,
  SkillState,
  UserProfile,
} from "./types";

const STORAGE_KEY = "starvizz_soft_skills_profile_v2";

const uid = () => Math.random().toString(36).slice(2, 10);
const today = () => new Date().toISOString();

function defaultSkillState(): SkillState {
  return {
    score: 0,
    level: "foundation",
    status: "developing",
    unlockedLevels: ["foundation"],
    touchedDimensions: [],
  };
}

export function defaultProfile(): UserProfile {
  const skills = {} as UserProfile["skills"];
  (["listening", "speaking", "reading", "writing"] as Skill[]).forEach((skill) => {
    skills[skill] = defaultSkillState();
  });

  const dimensions = {} as UserProfile["dimensions"];
  DIMENSIONS.forEach((dim) => {
    dimensions[dim] = { score: 0, status: "developing" };
  });

  return {
    hasCompletedBaseline: false,
    skills,
    dimensions,
    mistakeBank: [],
    activityLog: [],
    levelAssessmentHistory: [],
    certificates: [],
    totalXp: 0,
    streak: { lastActiveDate: null, count: 0 },
  };
}

export function loadProfile(): UserProfile {
  if (typeof window === "undefined") return defaultProfile();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProfile();
    const parsed = JSON.parse(raw) as UserProfile;
    const fallback = defaultProfile();
    return {
      ...fallback,
      ...parsed,
      skills: { ...fallback.skills, ...parsed.skills },
      dimensions: { ...fallback.dimensions, ...parsed.dimensions },
    };
  } catch {
    return defaultProfile();
  }
}

export function saveProfile(profile: UserProfile): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
}

export function resetProfile(): UserProfile {
  const fresh = defaultProfile();
  saveProfile(fresh);
  return fresh;
}

// ---------------------------------------------------------------------------
// Streak
// ---------------------------------------------------------------------------

export function touchStreak(profile: UserProfile): UserProfile {
  const todayDate = new Date().toDateString();
  const last = profile.streak.lastActiveDate
    ? new Date(profile.streak.lastActiveDate).toDateString()
    : null;

  if (last === todayDate) return profile;

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const wasYesterday = last === yesterday.toDateString();

  return {
    ...profile,
    streak: {
      lastActiveDate: today(),
      count: wasYesterday ? profile.streak.count + 1 : 1,
    },
  };
}

// ---------------------------------------------------------------------------
// Dimension blending helper
// ---------------------------------------------------------------------------

function blendDimensions(
  profile: UserProfile,
  dimensionScores: Partial<Record<Dimension, number>>,
  weight: number
): UserProfile["dimensions"] {
  const dimensions = { ...profile.dimensions };
  (Object.keys(dimensionScores) as Dimension[]).forEach((dim) => {
    const incoming = dimensionScores[dim]!;
    const current = dimensions[dim];
    const nextScore = Math.round(current.score * (1 - weight) + incoming * weight);
    dimensions[dim] = { score: nextScore, status: statusForScore(nextScore) };
  });
  return dimensions;
}

// ---------------------------------------------------------------------------
// Baseline placement
// ---------------------------------------------------------------------------

export function applyBaselineResults(
  profile: UserProfile,
  perSkillScores: Record<Skill, number>,
  dimensionScores: Partial<Record<Dimension, number>>,
  deriveLevel: (score: number) => Level
): UserProfile {
  const skills = { ...profile.skills };
  const activityLog: ActivityLogEntry[] = [...profile.activityLog];

  (Object.keys(perSkillScores) as Skill[]).forEach((skill) => {
    const score = perSkillScores[skill];
    const level = deriveLevel(score);
    const levelOrder = LEVELS.indexOf(level);
    const unlockedLevels = LEVELS.slice(0, levelOrder + 1);

    skills[skill] = {
      score,
      level,
      status: statusForScore(score),
      unlockedLevels,
      touchedDimensions: [],
    };

    activityLog.push({
      id: uid(),
      date: today(),
      skill,
      level,
      type: "baseline",
      score,
      xpEarned: 0,
    });
  });

  const dimensions = blendDimensions({ ...profile, dimensions: profile.dimensions }, dimensionScores, 1);

  return touchStreak({
    ...profile,
    hasCompletedBaseline: true,
    skills,
    dimensions,
    activityLog,
  });
}

// ---------------------------------------------------------------------------
// Mistake bank
// ---------------------------------------------------------------------------

export function addMistakesToBank(
  profile: UserProfile,
  skill: Skill,
  mistakes: DetectedMistake[]
): UserProfile {
  if (mistakes.length === 0) return profile;
  let bank = [...profile.mistakeBank];

  for (const m of mistakes) {
    const existingIndex = bank.findIndex((b) => b.skill === skill && b.category === m.category);
    if (existingIndex >= 0) {
      bank[existingIndex] = {
        ...bank[existingIndex],
        count: bank[existingIndex].count + 1,
        example: m.original,
        correction: m.correction,
        lastSeen: today(),
      };
    } else {
      bank.push({
        id: uid(),
        skill,
        dimension: m.dimension,
        category: m.category,
        example: m.original,
        correction: m.correction,
        count: 1,
        lastSeen: today(),
      });
    }
  }

  bank = bank.sort((a, b) => b.count - a.count);
  return { ...profile, mistakeBank: bank };
}

// ---------------------------------------------------------------------------
// Practice (non-gating) activity — one "module" or "capstone" session
// ---------------------------------------------------------------------------

export function recordPracticeResult(
  profile: UserProfile,
  skill: Skill,
  level: Level,
  responseScore: number,
  mistakes: DetectedMistake[],
  dimensionScores: Partial<Record<Dimension, number>>,
  xpEarned: number
): UserProfile {
  const current = profile.skills[skill];
  const nextScore = Math.round(current.score * 0.7 + responseScore * 0.3);
  const touchedDimensions = Array.from(
    new Set([...current.touchedDimensions, ...(Object.keys(dimensionScores) as Dimension[])])
  );

  const skills = {
    ...profile.skills,
    [skill]: {
      ...current,
      score: nextScore,
      status: statusForScore(nextScore),
      touchedDimensions,
    },
  };

  const activityLog: ActivityLogEntry[] = [
    ...profile.activityLog,
    { id: uid(), date: today(), skill, level, type: "practice", score: responseScore, xpEarned },
  ];

  let next: UserProfile = {
    ...profile,
    skills,
    activityLog,
    dimensions: blendDimensions(profile, dimensionScores, 0.3),
    totalXp: profile.totalXp + xpEarned,
  };
  next = addMistakesToBank(next, skill, mistakes);
  return touchStreak(next);
}

// ---------------------------------------------------------------------------
// Level (gating) assessment
// ---------------------------------------------------------------------------

export function recordLevelAssessment(
  profile: UserProfile,
  skill: Skill,
  level: Level,
  score: number,
  mistakes: DetectedMistake[],
  gaps: string[],
  dimensionScores: Partial<Record<Dimension, number>>
): { profile: UserProfile; passed: boolean; certificate?: Certificate; xpEarned: number } {
  const threshold = passThresholdFor(level);
  const passed = score >= threshold;
  const current = profile.skills[skill];
  const xpEarned = passed ? XP.levelAssessmentPass : 0;

  const result: LevelAssessmentResult = {
    id: uid(),
    skill,
    level,
    score,
    passed,
    date: today(),
    gaps,
  };

  let unlockedLevels = current.unlockedLevels;
  let newLevel = current.level;
  let certificate: Certificate | undefined;

  if (passed) {
    const currentOrder = LEVELS.indexOf(level);
    const nextLevel = LEVELS[currentOrder + 1];
    unlockedLevels = Array.from(new Set([...current.unlockedLevels, ...(nextLevel ? [nextLevel] : [])]));
    newLevel = nextLevel ?? level;
    certificate = { id: uid(), skill, level, score, issuedDate: today() };
  }

  const nextSkillScore = Math.round(current.score * 0.5 + score * 0.5);

  const skills = {
    ...profile.skills,
    [skill]: {
      ...current,
      score: nextSkillScore,
      level: newLevel,
      status: statusForScore(nextSkillScore),
      unlockedLevels,
    },
  };

  const activityLog: ActivityLogEntry[] = [
    ...profile.activityLog,
    { id: uid(), date: today(), skill, level, type: "level-assessment", score, xpEarned },
  ];

  let next: UserProfile = {
    ...profile,
    skills,
    activityLog,
    levelAssessmentHistory: [...profile.levelAssessmentHistory, result],
    certificates: certificate ? [...profile.certificates, certificate] : profile.certificates,
    dimensions: blendDimensions(profile, dimensionScores, 0.5),
    totalXp: profile.totalXp + xpEarned,
  };
  next = addMistakesToBank(next, skill, mistakes);
  next = touchStreak(next);

  return { profile: next, passed, certificate, xpEarned };
}

// ---------------------------------------------------------------------------
// Today's practice recommendation
// ---------------------------------------------------------------------------

export interface PracticeRecommendation {
  skill: Skill;
  level: Level;
  reason: string;
}

export function getTodaysPractice(profile: UserProfile): {
  focusDimension: Dimension | null;
  recommendations: PracticeRecommendation[];
} {
  if (!profile.hasCompletedBaseline) return { focusDimension: null, recommendations: [] };

  const dimensionEntries = DIMENSIONS.map((dim) => ({ dim, state: profile.dimensions[dim] }));
  const weakestDimension = [...dimensionEntries].sort((a, b) => a.state.score - b.state.score)[0];

  const skillEntries = (["listening", "speaking", "reading", "writing"] as Skill[]).map((skill) => ({
    skill,
    state: profile.skills[skill],
  }));
  const weakestSkills = [...skillEntries].sort((a, b) => a.state.score - b.state.score).slice(0, 3);

  return {
    focusDimension: weakestDimension?.dim ?? null,
    recommendations: weakestSkills.map(({ skill, state }) => ({
      skill,
      level: state.level,
      reason:
        state.status === "developing"
          ? "This is currently your priority area."
          : "A quick refresh will help you reach mastery.",
    })),
  };
}
