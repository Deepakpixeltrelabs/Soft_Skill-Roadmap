// Core domain types for the Starvizz Soft Skills Roadmap product.

// Skills — the four tracks that get a roadmap, a level and progression.
// Grammar/Vocabulary/etc are NOT skills — they are "supporting dimensions"
// measured *within* an LSRW activity (see Dimension below).
export type Skill = "listening" | "speaking" | "reading" | "writing";

export const SKILLS: Skill[] = ["listening", "speaking", "reading", "writing"];

// Supporting dimensions — cross-cutting competencies. Every question is
// tagged with one or more of these; every feedback report and mistake
// surfaces which dimension it belongs to; the dashboard shows a profile-wide
// breakdown. They never get their own roadmap/level — they roll up into
// whichever LSRW skill the question belonged to.
export type Dimension =
  | "grammar"
  | "vocabulary"
  | "pronunciation"
  | "fluency"
  | "comprehension"
  | "sentenceConstruction"
  | "professionalCommunication"
  | "confidence"
  | "tone"
  | "criticalThinking"
  | "workplaceCommunication";

export const DIMENSIONS: Dimension[] = [
  "grammar",
  "vocabulary",
  "pronunciation",
  "fluency",
  "comprehension",
  "sentenceConstruction",
  "professionalCommunication",
  "confidence",
  "tone",
  "criticalThinking",
  "workplaceCommunication",
];

// Levels — renamed from Basic/Intermediate/Advanced/Expert.
export type Level = "foundation" | "development" | "professional" | "mastery";

export const LEVELS: Level[] = ["foundation", "development", "professional", "mastery"];

export type SkillStatus = "developing" | "proficient" | "mastered";

export type QuestionType = "mcq" | "reading" | "listening" | "writing" | "speaking";

export interface McqOption {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  skill: Skill;
  level: Level;
  type: QuestionType;
  prompt: string;
  passage?: string;
  options?: McqOption[];
  correctOptionId?: string;
  rubricHints?: string[];
  /** Which supporting dimensions this question exercises / is scored against. */
  dimensions: Dimension[];
}

export interface DetectedMistake {
  id: string;
  category: string;
  dimension: Dimension;
  original: string;
  correction: string;
  why: string;
}

export interface FeedbackReport {
  questionId: string;
  skill: Skill;
  dimensions: Dimension[];
  score: number;
  whatYouDid: string;
  whatWentWrong: string;
  whyItsWrong: string;
  howToImprove: string;
  practiceAgain: string;
  mistakes: DetectedMistake[];
  strengths: string[];
}

export interface MistakeEntry {
  id: string;
  skill: Skill;
  dimension: Dimension;
  category: string;
  example: string;
  correction: string;
  count: number;
  lastSeen: string;
}

export interface ActivityLogEntry {
  id: string;
  date: string;
  skill: Skill;
  level: Level;
  type: "practice" | "level-assessment" | "baseline";
  score: number;
  xpEarned: number;
}

export interface LevelAssessmentResult {
  id: string;
  skill: Skill;
  level: Level;
  score: number;
  passed: boolean;
  date: string;
  gaps: string[];
}

export interface Certificate {
  id: string;
  skill: Skill;
  level: Level;
  score: number;
  issuedDate: string;
}

export interface SkillState {
  score: number;
  level: Level;
  status: SkillStatus;
  unlockedLevels: Level[];
  /** Dimensions the student has practiced at least once within this skill (drives module "In Progress" state). */
  touchedDimensions: Dimension[];
}

export interface DimensionState {
  score: number;
  status: SkillStatus;
}

export interface UserProfile {
  hasCompletedBaseline: boolean;
  skills: Record<Skill, SkillState>;
  dimensions: Record<Dimension, DimensionState>;
  mistakeBank: MistakeEntry[];
  activityLog: ActivityLogEntry[];
  levelAssessmentHistory: LevelAssessmentResult[];
  certificates: Certificate[];
  totalXp: number;
  streak: {
    lastActiveDate: string | null;
    count: number;
  };
}

export interface AnswerSubmission {
  questionId: string;
  skill: Skill;
  type: QuestionType;
  selectedOptionId?: string;
  textResponse?: string;
}
