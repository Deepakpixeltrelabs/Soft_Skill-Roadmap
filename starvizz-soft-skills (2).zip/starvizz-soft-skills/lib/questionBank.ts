import { Dimension, Level, Question, Skill } from "./types";

// A small but structured bank of content. New items can be appended without
// touching any component or scoring code. Every question is tagged with the
// supporting dimension(s) it exercises — Grammar and Vocabulary items are
// NOT separate skills, they're just questions tagged with those dimensions
// and filed under whichever LSRW skill they naturally belong to.

export const QUESTION_BANK: Question[] = [
  // ---------------------------------------------------------------- LISTENING
  {
    id: "lis-f-1",
    skill: "listening",
    level: "foundation",
    type: "listening",
    prompt: "What is the manager asking Priya to do?",
    passage:
      '"Priya, can you send me the client report before lunch? I need to review it before the 2 PM call."',
    options: [
      { id: "a", text: "Attend the 2 PM call" },
      { id: "b", text: "Send the client report before lunch" },
      { id: "c", text: "Cancel the client call" },
      { id: "d", text: "Review the report herself" },
    ],
    correctOptionId: "b",
    dimensions: ["comprehension"],
  },
  {
    id: "lis-f-2",
    skill: "listening",
    level: "foundation",
    type: "listening",
    prompt: "Where is the meeting taking place?",
    passage:
      '"Hey, just a reminder — today\'s stand-up moved to Conference Room B, not the usual room."',
    options: [
      { id: "a", text: "Conference Room A" },
      { id: "b", text: "Conference Room B" },
      { id: "c", text: "It was cancelled" },
      { id: "d", text: "Online" },
    ],
    correctOptionId: "b",
    dimensions: ["comprehension"],
  },
  {
    id: "lis-d-1",
    skill: "listening",
    level: "development",
    type: "listening",
    prompt: "What does the speaker recommend as the next step?",
    passage:
      '"We\'ve looked at the numbers, and honestly, I think we should pause the campaign for two weeks and revisit the targeting before we spend more budget."',
    options: [
      { id: "a", text: "Increase the budget immediately" },
      { id: "b", text: "Pause the campaign and revisit targeting" },
      { id: "c", text: "End the campaign permanently" },
      { id: "d", text: "Launch a new campaign" },
    ],
    correctOptionId: "b",
    dimensions: ["comprehension", "workplaceCommunication"],
  },
  {
    id: "lis-d-2",
    skill: "listening",
    level: "development",
    type: "listening",
    prompt: "What is the overall tone of the speaker?",
    passage:
      '"Look, I get that the timeline is tight, but if we rush this, we\'ll ship something broken. I\'d rather we take two extra days and get it right."',
    options: [
      { id: "a", text: "Indifferent" },
      { id: "b", text: "Cautious and firm" },
      { id: "c", text: "Angry" },
      { id: "d", text: "Excited" },
    ],
    correctOptionId: "b",
    dimensions: ["tone"],
  },
  {
    id: "lis-p-1",
    skill: "listening",
    level: "professional",
    type: "listening",
    prompt: "What is implied but not directly stated?",
    passage:
      '"The client said the proposal looked \'interesting\' and that they\'d \'circle back after the holidays.\'"',
    options: [
      { id: "a", text: "The client will sign immediately" },
      { id: "b", text: "The client is likely hesitant or non-committal" },
      { id: "c", text: "The client rejected the proposal outright" },
      { id: "d", text: "The client wants a discount" },
    ],
    correctOptionId: "b",
    dimensions: ["criticalThinking", "tone"],
  },
  {
    id: "lis-m-1",
    skill: "listening",
    level: "mastery",
    type: "listening",
    prompt: "In this negotiation clip, what is the other party's underlying priority?",
    passage:
      '"We\'re not against the price. Our concern is really about the delivery timeline — if that slips again, it affects three other teams downstream."',
    options: [
      { id: "a", text: "Reducing the price" },
      { id: "b", text: "Delivery timeline reliability" },
      { id: "c", text: "Changing the product scope" },
      { id: "d", text: "Switching vendors" },
    ],
    correctOptionId: "b",
    dimensions: ["criticalThinking", "workplaceCommunication"],
  },

  // ----------------------------------------------------------------- SPEAKING
  {
    id: "spk-f-1",
    skill: "speaking",
    level: "foundation",
    type: "speaking",
    prompt: "Introduce yourself in 3-4 sentences: your name, role, and one thing you enjoy about your work.",
    rubricHints: ["Clear structure", "Simple correct sentences", "Confident tone"],
    dimensions: ["confidence", "sentenceConstruction"],
  },
  {
    id: "spk-d-1",
    skill: "speaking",
    level: "development",
    type: "speaking",
    prompt: "Describe a challenge you faced at work recently and how you handled it.",
    rubricHints: ["Situation, action, result structure", "Fluency", "Relevant vocabulary"],
    dimensions: ["fluency", "sentenceConstruction"],
  },
  {
    id: "spk-p-1",
    skill: "speaking",
    level: "professional",
    type: "speaking",
    prompt: "You have 60 seconds: persuade a teammate to adopt a new tool you believe will save the team time.",
    rubricHints: ["Persuasive structure", "Addressing objections", "Confident delivery"],
    dimensions: ["confidence", "workplaceCommunication"],
  },
  {
    id: "spk-m-1",
    skill: "speaking",
    level: "mastery",
    type: "speaking",
    prompt: "A client is upset about a missed deadline. Respond as if speaking to them directly, acknowledging the issue and proposing next steps.",
    rubricHints: ["Empathy", "Ownership without over-apologizing", "Clear resolution plan"],
    dimensions: ["workplaceCommunication", "confidence"],
  },

  // ------------------------------------------------------------------ READING
  {
    id: "read-f-1",
    skill: "reading",
    level: "foundation",
    type: "reading",
    prompt: "What is the main idea of this passage?",
    passage:
      "Maria works at a small bakery. Every morning she arrives at 6 AM to prepare fresh bread before the shop opens at 8 AM.",
    options: [
      { id: "a", text: "Maria owns a bakery chain" },
      { id: "b", text: "Maria prepares bread early each morning before opening" },
      { id: "c", text: "The bakery is closed on weekdays" },
      { id: "d", text: "Maria dislikes her job" },
    ],
    correctOptionId: "b",
    dimensions: ["comprehension"],
  },
  {
    id: "read-d-1",
    skill: "reading",
    level: "development",
    type: "reading",
    prompt: "What can you infer the sender wants from the recipient?",
    passage:
      "Hi team, quick note — the client deck needs another pass before Thursday. If anyone has bandwidth today, please review slides 4-9 for accuracy.",
    options: [
      { id: "a", text: "Someone to review slides 4-9 today" },
      { id: "b", text: "The meeting to be rescheduled" },
      { id: "c", text: "Feedback on the whole deck by tomorrow only" },
      { id: "d", text: "A new deck to be created from scratch" },
    ],
    correctOptionId: "a",
    dimensions: ["comprehension", "workplaceCommunication"],
  },
  {
    id: "read-p-1",
    skill: "reading",
    level: "professional",
    type: "reading",
    prompt: "Which statement best reflects the author's underlying argument?",
    passage:
      "While automation has reduced manual workload, teams that skipped investing in process documentation are now struggling to scale — the tools moved faster than the habits needed to use them well.",
    options: [
      { id: "a", text: "Automation is the main cause of scaling problems" },
      { id: "b", text: "Process documentation matters as much as the tools themselves" },
      { id: "c", text: "Manual work is always better than automation" },
      { id: "d", text: "Teams should avoid automation entirely" },
    ],
    correctOptionId: "b",
    dimensions: ["criticalThinking"],
  },
  {
    id: "read-m-1",
    skill: "reading",
    level: "mastery",
    type: "reading",
    prompt: "What assumption is the report making that isn't explicitly stated?",
    passage:
      "Revenue grew 12% quarter-over-quarter following the pricing change, suggesting the new pricing model is working well.",
    options: [
      { id: "a", text: "That no other factor (seasonality, marketing spend) contributed to growth" },
      { id: "b", text: "That revenue will keep growing indefinitely" },
      { id: "c", text: "That customers dislike the new pricing" },
      { id: "d", text: "That the pricing change was reversed" },
    ],
    correctOptionId: "a",
    dimensions: ["criticalThinking"],
  },
  // Reading also carries the vocabulary-in-context items (vocabulary is a
  // supporting dimension of reading, not a separate skill).
  {
    id: "read-f-2",
    skill: "reading",
    level: "foundation",
    type: "mcq",
    prompt: 'Which word best completes: "Please ___ the door before you leave."',
    options: [
      { id: "a", text: "close" },
      { id: "b", text: "closed" },
      { id: "c", text: "closing" },
      { id: "d", text: "closes" },
    ],
    correctOptionId: "a",
    dimensions: ["vocabulary", "grammar"],
  },
  {
    id: "read-d-2",
    skill: "reading",
    level: "development",
    type: "mcq",
    prompt: 'In a workplace email, which word is most appropriate: "I wanted to ___ you on the project status."',
    options: [
      { id: "a", text: "update" },
      { id: "b", text: "gossip" },
      { id: "c", text: "chat" },
      { id: "d", text: "text" },
    ],
    correctOptionId: "a",
    dimensions: ["vocabulary", "professionalCommunication"],
  },
  {
    id: "read-p-2",
    skill: "reading",
    level: "professional",
    type: "mcq",
    prompt: 'Which word best fits: "The team took a ___ approach, weighing every risk before deciding."',
    options: [
      { id: "a", text: "reckless" },
      { id: "b", text: "measured" },
      { id: "c", text: "hasty" },
      { id: "d", text: "careless" },
    ],
    correctOptionId: "b",
    dimensions: ["vocabulary"],
  },
  {
    id: "read-m-2",
    skill: "reading",
    level: "mastery",
    type: "mcq",
    prompt: 'Choose the word with the most precise, professional connotation: "The client\'s feedback was ___."',
    options: [
      { id: "a", text: "kind of harsh" },
      { id: "b", text: "candid" },
      { id: "c", text: "mean" },
      { id: "d", text: "weird" },
    ],
    correctOptionId: "b",
    dimensions: ["vocabulary", "tone"],
  },

  // ------------------------------------------------------------------ WRITING
  {
    id: "wri-f-1",
    skill: "writing",
    level: "foundation",
    type: "writing",
    prompt: "Write 2-3 sentences describing what you did at work yesterday.",
    rubricHints: ["Correct past tense", "Clear sentence structure"],
    dimensions: ["grammar", "sentenceConstruction"],
  },
  {
    id: "wri-d-1",
    skill: "writing",
    level: "development",
    type: "writing",
    prompt: "Write a short email to your manager explaining you will not be able to attend tomorrow's meeting due to a personal commitment.",
    rubricHints: ["Polite tone", "Clear reason", "Offer of an alternative"],
    dimensions: ["professionalCommunication", "tone"],
  },
  {
    id: "wri-p-1",
    skill: "writing",
    level: "professional",
    type: "writing",
    prompt: "Write a short paragraph proposing that your team adopt a 4-day meeting-free block each week, addressing one likely objection.",
    rubricHints: ["Professional tone", "Structured argument", "Addresses a counterpoint"],
    dimensions: ["professionalCommunication", "sentenceConstruction"],
  },
  {
    id: "wri-m-1",
    skill: "writing",
    level: "mastery",
    type: "writing",
    prompt: "Write a brief executive summary (3-4 sentences) explaining a project delay to leadership, owning the issue and stating the recovery plan.",
    rubricHints: ["Executive tone", "Ownership", "Concrete recovery plan"],
    dimensions: ["professionalCommunication", "tone"],
  },
  // Writing also carries the grammar drill items (grammar is a supporting
  // dimension of writing, not a separate skill).
  {
    id: "wri-f-2",
    skill: "writing",
    level: "foundation",
    type: "mcq",
    prompt: "Choose the correct sentence.",
    options: [
      { id: "a", text: "She go to office every day." },
      { id: "b", text: "She goes to office every day." },
      { id: "c", text: "She going to office every day." },
      { id: "d", text: "She gone to office every day." },
    ],
    correctOptionId: "b",
    dimensions: ["grammar"],
  },
  {
    id: "wri-f-3",
    skill: "writing",
    level: "foundation",
    type: "mcq",
    prompt: "Fill in the blank: I ___ working here since 2022.",
    options: [
      { id: "a", text: "am" },
      { id: "b", text: "have been" },
      { id: "c", text: "was" },
      { id: "d", text: "will be" },
    ],
    correctOptionId: "b",
    dimensions: ["grammar"],
  },
  {
    id: "wri-d-2",
    skill: "writing",
    level: "development",
    type: "mcq",
    prompt: "Choose the correct preposition: We need to discuss ___ the proposal.",
    options: [
      { id: "a", text: "about" },
      { id: "b", text: "(no preposition needed)" },
      { id: "c", text: "on" },
      { id: "d", text: "of" },
    ],
    correctOptionId: "b",
    dimensions: ["grammar"],
  },
  {
    id: "wri-p-2",
    skill: "writing",
    level: "professional",
    type: "mcq",
    prompt: "Choose the correctly formed passive sentence.",
    options: [
      { id: "a", text: "The report was reviewed by the manager yesterday." },
      { id: "b", text: "The report reviewed by the manager yesterday." },
      { id: "c", text: "The manager was reviewed the report yesterday." },
      { id: "d", text: "The report is reviewing by the manager yesterday." },
    ],
    correctOptionId: "a",
    dimensions: ["grammar"],
  },
  {
    id: "wri-m-2",
    skill: "writing",
    level: "mastery",
    type: "mcq",
    prompt: "Which sentence uses reported speech correctly?",
    options: [
      { id: "a", text: 'She said that she "will finish" it tomorrow.' },
      { id: "b", text: "She said that she would finish it the next day." },
      { id: "c", text: "She said she finish it tomorrow." },
      { id: "d", text: "She say that she will finish it tomorrow." },
    ],
    correctOptionId: "b",
    dimensions: ["grammar"],
  },
];

export function getQuestionsBySkillLevel(skill: Skill, level: Level): Question[] {
  return QUESTION_BANK.filter((q) => q.skill === skill && q.level === level);
}

export function getQuestionsBySkillLevelDimension(
  skill: Skill,
  level: Level,
  dimension: Dimension
): Question[] {
  return QUESTION_BANK.filter(
    (q) => q.skill === skill && q.level === level && q.dimensions.includes(dimension)
  );
}

export function getBaselineQuestions(): Question[] {
  // Baseline pulls one foundation + one development item per skill so the
  // AI profiler has enough signal to place each skill independently.
  const picks: Question[] = [];
  const skills: Skill[] = ["listening", "speaking", "reading", "writing"];
  for (const skill of skills) {
    const foundation = getQuestionsBySkillLevel(skill, "foundation");
    const development = getQuestionsBySkillLevel(skill, "development");
    if (foundation[0]) picks.push(foundation[0]);
    if (development[0]) picks.push(development[0]);
  }
  return picks;
}

export function getLevelAssessmentQuestions(skill: Skill, level: Level): Question[] {
  return getQuestionsBySkillLevel(skill, level);
}

export function getQuestionById(id: string): Question | undefined {
  return QUESTION_BANK.find((q) => q.id === id);
}
