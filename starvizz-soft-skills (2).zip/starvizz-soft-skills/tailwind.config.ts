import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f0f9f4",
          100: "#dcf1e4",
          200: "#bce3cd",
          300: "#8ccdac",
          400: "#57b085",
          500: "#339467",
          600: "#237852",
          700: "#1c6043",
          800: "#194d38",
          900: "#154030",
          950: "#0a231a",
        },
        ink: {
          50: "#f6f7f8",
          100: "#eceef1",
          200: "#d5dae0",
          300: "#b0b9c4",
          400: "#8593a3",
          500: "#657488",
          600: "#505d70",
          700: "#424c5b",
          800: "#39414d",
          900: "#333943",
          950: "#20242b",
        },
        developing: "#e0552b",
        proficient: "#d9a017",
        mastered: "#2f9e5b",
        primary: {
          50: "#f1efff",
          100: "#e4e0ff",
          400: "#8b7cf6",
          500: "#6d5ae8",
          600: "#5b48d1",
          700: "#4c3bb0",
        },
        mint: {
          50: "#eef7ee",
          100: "#e1f0e0",
        },
        xp: {
          bg: "#fef3e2",
          text: "#b8730a",
        },
      },
      fontFamily: {
        sans: [
          "Inter",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "sans-serif",
        ],
      },
      boxShadow: {
        card: "0 1px 2px rgba(20,24,30,0.04), 0 4px 16px rgba(20,24,30,0.06)",
        raised: "0 8px 24px rgba(20,24,30,0.10)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};

export default config;
