# Starvizz — Soft Skills Roadmap

A Next.js 14 (App Router) implementation of the **Baseline Assessment → AI
Skill Profiling → Personalized Roadmap → Practice → AI Feedback → Level
Assessment → Level Unlock** loop, restyled to match the reference mobile app
(floating-island "Learning Path", mint header bars, module/capstone/assessment
level-detail screens, XP chips, bottom tab bar with a raised center action).

This is a **working, click-through product**, not a static mockup: state
persists in `localStorage`, the "AI" scoring/feedback engine is a real
(if simple, rule-based) implementation you can inspect and extend, and every
screen reads from and writes to a single `UserProfile` object.

## Skills vs. supporting dimensions

Only four things get their own roadmap, level and progress bar:

**Listening, Speaking, Reading, Writing (LSRW)**

Everything else — **Grammar, Vocabulary, Pronunciation, Fluency,
Comprehension, Sentence Construction, Professional Communication,
Confidence, Tone, Critical Thinking, Workplace Communication** — is a
**supporting dimension**. Dimensions are not separate skills: every question
in the bank is tagged with the dimension(s) it exercises (see
`lib/questionBank.ts`), every mistake the AI detects is tagged with a
dimension (see `MISTAKE_PATTERNS` in `lib/constants.ts`), and every 5-layer
feedback report surfaces those dimension tags. The dashboard shows a
profile-wide "Supporting Dimensions" breakdown (`DimensionHeatmap.tsx`) fed
by every activity across all four skills — but a dimension never gates a
level on its own; it rolls up into whichever LSRW skill it was measured in.

## Levels

Renamed from Basic/Intermediate/Advanced/Expert to:

**Foundation → Development → Professional → Mastery**

(`Level` type and `LEVEL_META` in `lib/types.ts` / `lib/constants.ts`.)

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000. Take the baseline assessment first — most other
screens are locked behind it (deliberately, per the product loop).

To reset your demo profile, run in devtools:
```js
localStorage.removeItem("starvizz_soft_skills_profile_v2")
```

## Screen flow (matches the reference app)

1. **Dashboard** (`/`) — skill heatmap (LSRW), supporting-dimension
   breakdown, today's practice (weakest dimension + weakest skills), XP,
   streak, certificates.
2. **Roadmap overview** (`/roadmap`) — the 4 skills as cards.
3. **Learning Path** (`/roadmap/[skill]`) — floating-island progression map,
   Foundation → Mastery, mirroring the reference app's islands screen.
4. **Level detail** (`/roadmap/[skill]/[level]`) — the "Foundations"-style
   screen: hero card with progress, a **Modules** list (one per supporting
   dimension relevant to that skill — tapping one launches a dimension-filtered
   practice set), a **Capstone Practice** card (the full mixed question set
   for that skill+level), and an **Assessment** card ("Level Test" with
   question count / XP / pass threshold and a "Start Assessment" button).
5. **Practice session** (`/practice/[skill]/[level]?dimension=xyz`) — runs
   the module (dimension-filtered) or capstone (full) question set, then
   shows a 5-layer AI feedback report per question, each tagged with its
   supporting dimension(s).
6. **Level assessment** (`/assessment/level/[skill]/[level]`) — the gating
   test. Passing unlocks the next level and issues a certificate; failing
   shows targeted remediation gaps to practice before retrying.
7. **Mistake Bank** (`/mistake-bank`) — recurring mistakes tagged by skill
   *and* dimension, with a "smart revision" prompt once a mistake repeats.
8. **Certificate** (`/certificate/[skill]/[level]`).

## Project structure

```
app/
  page.tsx                                Dashboard
  assessment/
    baseline/page.tsx                     Baseline diagnostic
    level/[skill]/[level]/page.tsx        Gating level-up assessment
  results/baseline/page.tsx               AI skill profiling results table
  roadmap/
    page.tsx                              4-skill overview
    [skill]/page.tsx                      Floating-island Learning Path
    [skill]/[level]/page.tsx              "Foundations"-style level detail
                                           (Modules / Capstone / Assessment)
  practice/
    page.tsx                              Practice hub
    [skill]/[level]/page.tsx              Practice session + feedback
  mistake-bank/page.tsx                   Improvement Bank
  certificate/[skill]/[level]/page.tsx

components/
  Nav.tsx                 Bottom tab bar with raised center FAB (Practice)
  MobileHeader.tsx         Mint top app bar (back button, title, subtitle)
  SkillHeatmap.tsx         LSRW score bars
  DimensionHeatmap.tsx     Supporting-dimension breakdown (collapsible)
  TodaysPractice.tsx       "Today's focus: <dimension>" + recommended skills
  ProgressionMap.tsx       Floating-island progression visual per skill
  AssessmentRunner.tsx     Generic question-by-question runner, shows
                           dimension chips per question
  FeedbackReportView.tsx   5-layer AI feedback + dimension chips per mistake
  Badges.tsx               Level / status / score pill components
  LoadingState.tsx

lib/
  types.ts          Skill (4), Dimension (11), Level (Foundation..Mastery),
                     Question, FeedbackReport, UserProfile, etc.
  constants.ts       SKILL_META, DIMENSION_META, SKILL_DIMENSIONS (which
                      dimensions matter for which skill), LEVEL_META,
                      LEVEL_DESCRIPTIONS, XP rewards, curated mistake-pattern
                      bank (each pattern tagged with its dimension)
  questionBank.ts    All question content. Grammar/vocabulary items live
                      here tagged with `dimensions: ["grammar"]` /
                      `["vocabulary"]` under Writing/Reading — not as their
                      own skill.
  mockAI.ts          Text analysis, mistake detection, 5-layer feedback
                      generation, level placement, and
                      `aggregateDimensionScores()` which rolls per-question
                      scores up into a per-dimension score.
  storage.ts         Pure functions over UserProfile (baseline placement,
                      practice, level assessment, mistake bank, XP, streak,
                      today's-practice) + localStorage read/write. Blends
                      dimension scores into `profile.dimensions` on every
                      practice/assessment submission.
  useProfile.ts      React hook wrapping storage.ts with client state.
```

## Why it's split this way

- **`lib/mockAI.ts` is the single seam to swap for a real LLM.** Pure
  functions in, plain data out. Swapping `analyzeTextResponse` for a real
  API call means changing this one file only.
- **`lib/storage.ts` is the single seam to swap for a real backend.** Pure
  `(profile, ...) => profile` reducers plus a thin localStorage read/write
  pair at the bottom.
- **`lib/questionBank.ts` / `lib/constants.ts` are the content layer.**
  Adding a question, a mistake pattern, or changing which dimensions matter
  for a skill is a data change, not a code change.
- **`AssessmentRunner` is reused everywhere** questions are answered
  (baseline, module practice, capstone practice, level assessment) — they
  differ only in *which questions* are passed in and *what happens on
  completion*.

## What's mocked vs. real

- **Real:** the full navigation/state loop, localStorage persistence, MCQ
  scoring, level-unlock gating (score ≥ pass threshold → next level
  unlocked), dimension score roll-up and blending, mistake-bank merge/count
  logic, XP accrual, today's-practice recommendation (weakest dimension +
  weakest skills).
- **Mocked (by design, ready to wire up):** speaking/listening use typed
  text instead of real audio; the grammar/tone checker is a small curated
  regex pattern bank (`MISTAKE_PATTERNS`) rather than an LLM call; question
  content is a starter bank rather than an adaptive item pool.

## Extending it

- **Add a question:** append to `QUESTION_BANK` in `lib/questionBank.ts`,
  tagging it with the `dimensions` it exercises.
- **Add a grammar/tone pattern:** append to `MISTAKE_PATTERNS` in
  `lib/constants.ts` — `{ regex, category, dimension, correction(match), why }`.
- **Change which dimensions matter for a skill:** edit `SKILL_DIMENSIONS` in
  `lib/constants.ts` — this drives the "Modules" list on the level detail
  screen automatically.
- **Wire up a real AI backend:** replace the body of `analyzeTextResponse` /
  `buildFeedbackReport` in `lib/mockAI.ts` with an API call, keeping the same
  return shape.
- **Wire up a real backend for the profile:** replace `loadProfile` /
  `saveProfile` in `lib/storage.ts` with API calls.
