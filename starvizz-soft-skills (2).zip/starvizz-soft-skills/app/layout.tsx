import type { Metadata } from "next";
import "./globals.css";
import Nav from "@/components/Nav";

export const metadata: Metadata = {
  title: "Starvizz | Soft Skills Roadmap",
  description: "Assessment → Roadmap → Practice → Progression for professional communication skills.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-ink-50 font-sans antialiased">
        <div className="mx-auto min-h-screen w-full max-w-md bg-[#f6f7f8] shadow-[0_0_40px_rgba(0,0,0,0.04)]">
          <main className="w-full px-4 pb-24 pt-4 sm:px-6">{children}</main>
          <Nav />
        </div>
      </body>
    </html>
  );
}
