"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { SKILL_META } from "@/lib/constants";
import { Skill, SKILLS } from "@/lib/types";
import { LevelBadge, ScorePill, StatusBadge } from "@/components/Badges";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function BaselineResultsPage() {
  const { profile, isLoaded } = useProfile();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setReady(true), 900);
    return () => clearTimeout(t);
  }, []);

  if (!isLoaded || !profile) return <LoadingState />;

  if (!ready) {
    return <LoadingState label="Analyzing your responses across LSRW..." />;
  }

  const strongest = [...SKILLS].sort((a, b) => profile.skills[b].score - profile.skills[a].score)[0];
  const weakest = [...SKILLS].sort((a, b) => profile.skills[a].score - profile.skills[b].score)[0];

  return (
    <div>
      <MobileHeader title="Your Profile" showBack={false} />
      <div className="mx-auto max-w-2xl">
        <div className="mb-6 text-center">
          <div className="mb-2 text-4xl">✨</div>
          <h1 className="text-xl font-bold text-ink-900">Your Soft Skills Profile is ready</h1>
          <p className="mt-1 text-sm text-ink-500">
            Your strongest skill is <span className="font-semibold text-ink-800">{SKILL_META[strongest].label}</span>.
            Your priority area is <span className="font-semibold text-ink-800">{SKILL_META[weakest].label}</span>.
          </p>
        </div>

        <div className="overflow-hidden rounded-xl2 border border-ink-100 bg-white shadow-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50 text-left text-xs uppercase tracking-wide text-ink-400">
                <th className="px-4 py-2.5 font-medium">Skill</th>
                <th className="px-4 py-2.5 font-medium">Score</th>
                <th className="px-4 py-2.5 font-medium">Status</th>
                <th className="px-4 py-2.5 font-medium">Starting Level</th>
              </tr>
            </thead>
            <tbody>
              {(SKILLS as Skill[]).map((skill) => {
                const state = profile.skills[skill];
                return (
                  <tr key={skill} className="border-b border-ink-50 last:border-0">
                    <td className="px-4 py-3 font-medium text-ink-800">
                      <span className="mr-1.5">{SKILL_META[skill].icon}</span>
                      {SKILL_META[skill].label}
                    </td>
                    <td className="px-4 py-3">
                      <ScorePill score={state.score} />
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={state.status} />
                    </td>
                    <td className="px-4 py-3">
                      <LevelBadge level={state.level} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex justify-center">
          <Link
            href="/roadmap"
            className="rounded-full bg-primary-600 px-6 py-3 text-sm font-semibold text-white hover:bg-primary-700"
          >
            View My Personalized Roadmap →
          </Link>
        </div>
      </div>
    </div>
  );
}
