"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import AssessmentRunner, { RunnerResult } from "@/components/AssessmentRunner";
import FeedbackReportView from "@/components/FeedbackReportView";
import { getLevelAssessmentQuestions } from "@/lib/questionBank";
import { useProfile } from "@/lib/useProfile";
import { recordLevelAssessment } from "@/lib/storage";
import { aggregateScores, aggregateDimensionScores } from "@/lib/mockAI";
import { LEVELS, LEVEL_META, SKILL_META, passThresholdFor } from "@/lib/constants";
import { Level, Skill, SKILLS } from "@/lib/types";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function LevelAssessmentPage() {
  const params = useParams<{ skill: string; level: string }>();
  const { profile, isLoaded, setProfile } = useProfile();
  const [outcome, setOutcome] = useState<{
    results: RunnerResult[];
    score: number;
    passed: boolean;
    xpEarned: number;
  } | null>(null);

  if (!isLoaded || !profile) return <LoadingState />;

  const skill = params.skill as Skill;
  const level = params.level as Level;

  if (!SKILLS.includes(skill) || !LEVELS.includes(level)) {
    return <div className="py-10 text-center text-sm text-ink-500">Invalid assessment.</div>;
  }

  const questions = getLevelAssessmentQuestions(skill, level);
  const meta = SKILL_META[skill];
  const threshold = passThresholdFor(level);
  const nextLevel = LEVELS[LEVELS.indexOf(level) + 1];

  function handleComplete(runnerResults: RunnerResult[]) {
    const score = aggregateScores(runnerResults.map((r) => r.score));
    const allMistakes = runnerResults.flatMap((r) => r.feedback.mistakes);
    const gaps = Array.from(new Set(allMistakes.map((m) => m.category)));
    const dimensionScores = aggregateDimensionScores(
      runnerResults.map((r) => ({ question: r.question, score: r.score }))
    );

    const { profile: updated, passed, xpEarned } = recordLevelAssessment(
      profile!,
      skill,
      level,
      score,
      allMistakes,
      gaps,
      dimensionScores
    );
    setProfile(updated);
    setOutcome({ results: runnerResults, score, passed, xpEarned });
  }

  if (questions.length === 0) {
    return (
      <div>
        <MobileHeader title="Level Test" subtitle={`${meta.label} · ${LEVEL_META[level].label}`} />
        <div className="py-10 text-center text-sm text-ink-500">No assessment content available yet.</div>
      </div>
    );
  }

  if (outcome) {
    const gaps = Array.from(new Set(outcome.results.flatMap((r) => r.feedback.mistakes.map((m) => m.category))));

    return (
      <div>
        <MobileHeader title="Results" subtitle={`${meta.label} · ${LEVEL_META[level].label}`} />
        <div className="mx-auto max-w-xl">
          <div className="mb-6 text-center">
            <div className="mb-2 text-4xl">{outcome.passed ? "🟢" : "🔁"}</div>
            <h1 className="text-lg font-bold text-ink-900">
              {outcome.passed
                ? `${nextLevel ? LEVEL_META[nextLevel].label : "Full Mastery"} Unlocked!`
                : "Not quite there yet"}
            </h1>
            <p className="mt-1 text-sm text-ink-500">
              Score: <span className="font-semibold text-ink-800">{outcome.score}</span> / pass at {threshold}%
            </p>
            {outcome.passed && (
              <span className="mt-2 inline-block rounded-full bg-xp-bg px-3 py-1 text-xs font-bold text-xp-text">
                +{outcome.xpEarned} XP earned
              </span>
            )}
          </div>

          {!outcome.passed && gaps.length > 0 && (
            <div className="mb-5 rounded-xl2 border border-orange-200 bg-orange-50 p-4">
              <div className="mb-1.5 text-sm font-semibold text-orange-800">Targeted remediation</div>
              <p className="mb-2 text-xs text-orange-700">
                Focus your next practice sessions on these gaps before retrying:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {gaps.map((g) => (
                  <span key={g} className="rounded-full bg-white px-2.5 py-1 text-xs font-medium text-orange-700">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            {outcome.results.map((r) => (
              <FeedbackReportView key={r.question.id} question={r.question} feedback={r.feedback} />
            ))}
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            {outcome.passed ? (
              <>
                <Link
                  href={`/certificate/${skill}/${level}`}
                  className="rounded-full border border-ink-200 px-5 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
                >
                  View certificate
                </Link>
                <Link
                  href={`/roadmap/${skill}`}
                  className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
                >
                  Continue roadmap →
                </Link>
              </>
            ) : (
              <>
                <Link
                  href={`/roadmap/${skill}/${level}`}
                  className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
                >
                  Practice these gaps
                </Link>
                <Link
                  href={`/assessment/level/${skill}/${level}`}
                  className="rounded-full border border-ink-200 px-5 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
                >
                  Retry assessment
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title="Level Test" subtitle={`${meta.label} · ${LEVEL_META[level].label}`} />
      <p className="mb-4 text-center text-xs text-ink-400">
        Score {threshold}%+ to unlock {nextLevel ? LEVEL_META[nextLevel].label : "full mastery"}.
      </p>
      <AssessmentRunner questions={questions} onComplete={handleComplete} submitLabel="Submit for Evaluation" />
    </div>
  );
}
