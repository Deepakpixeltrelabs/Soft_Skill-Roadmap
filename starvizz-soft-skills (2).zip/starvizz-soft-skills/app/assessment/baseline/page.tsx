"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import AssessmentRunner, { RunnerResult } from "@/components/AssessmentRunner";
import { getBaselineQuestions } from "@/lib/questionBank";
import { aggregateScores, deriveLevelFromScore, aggregateDimensionScores } from "@/lib/mockAI";
import { useProfile } from "@/lib/useProfile";
import { applyBaselineResults } from "@/lib/storage";
import { Skill, SKILLS } from "@/lib/types";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function BaselineAssessmentPage() {
  const router = useRouter();
  const { profile, isLoaded, setProfile } = useProfile();
  const [started, setStarted] = useState(false);
  const questions = useMemo(() => getBaselineQuestions(), []);

  if (!isLoaded || !profile) return <LoadingState />;

  function handleComplete(results: RunnerResult[]) {
    const perSkillScores = {} as Record<Skill, number>;
    for (const skill of SKILLS) {
      const scores = results.filter((r) => r.question.skill === skill).map((r) => r.score);
      perSkillScores[skill] = aggregateScores(scores);
    }
    const dimensionScores = aggregateDimensionScores(results.map((r) => ({ question: r.question, score: r.score })));

    setProfile((prev) => applyBaselineResults(prev, perSkillScores, dimensionScores, deriveLevelFromScore));
    router.push("/results/baseline");
  }

  if (!started) {
    return (
      <div>
        <MobileHeader title="Baseline Assessment" />
        <div className="mx-auto max-w-lg py-8 text-center">
          <div className="mb-4 text-4xl">🧭</div>
          <h1 className="mb-2 text-xl font-bold text-ink-900">Baseline Soft Skills Diagnostic</h1>
          <p className="mb-6 text-sm text-ink-500">
            {questions.length} short questions across Listening, Speaking, Reading and Writing — each
            also scored on supporting dimensions like Grammar, Vocabulary, Fluency and Tone. There's no
            way to "fail" a baseline, it just helps us place you correctly.
          </p>
          <button
            onClick={() => setStarted(true)}
            className="rounded-full bg-primary-600 px-6 py-3 text-sm font-semibold text-white hover:bg-primary-700"
          >
            Begin Assessment
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title="Baseline Assessment" onBack={() => setStarted(false)} />
      <AssessmentRunner questions={questions} onComplete={handleComplete} submitLabel="Finish Assessment" />
    </div>
  );
}
