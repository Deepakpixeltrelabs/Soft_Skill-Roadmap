"use client";

import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { getTodaysPractice } from "@/lib/storage";
import SkillHeatmap from "@/components/SkillHeatmap";
import DimensionHeatmap from "@/components/DimensionHeatmap";
import TodaysPractice from "@/components/TodaysPractice";
import LoadingState from "@/components/LoadingState";
import { SKILL_META } from "@/lib/constants";
import { Skill } from "@/lib/types";

export default function DashboardPage() {
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState label="Loading your profile..." />;

  if (!profile.hasCompletedBaseline) {
    return (
      <div className="mx-auto max-w-lg py-10 text-center">
        <div className="mb-4 text-5xl">🎯</div>
        <h1 className="mb-2 text-2xl font-bold text-ink-900">
          Build professional communication skills, level by level
        </h1>
        <p className="mb-8 text-sm text-ink-500">
          Start with a short baseline assessment across Listening, Speaking, Reading and Writing.
          Starvizz will build a roadmap personalized to your current level in each skill.
        </p>
        <Link
          href="/assessment/baseline"
          className="inline-block rounded-full bg-primary-600 px-6 py-3 text-sm font-semibold text-white hover:bg-primary-700"
        >
          Start Baseline Assessment
        </Link>
        <p className="mt-3 text-xs text-ink-400">Takes about 8-10 minutes · 8 quick questions</p>

        <div className="mt-10 grid grid-cols-4 gap-3 text-left">
          {(Object.keys(SKILL_META) as Skill[]).map((skill) => (
            <div key={skill} className="rounded-lg border border-ink-100 bg-white p-2.5 text-center">
              <div className="text-lg">{SKILL_META[skill].icon}</div>
              <div className="mt-1 text-[11px] font-medium text-ink-600">{SKILL_META[skill].label}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const { focusDimension, recommendations } = getTodaysPractice(profile);
  const overallScore = Math.round(
    (Object.values(profile.skills).reduce((sum, s) => sum + s.score, 0) /
      Object.values(profile.skills).length) || 0
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-ink-900">Welcome back 👋</h1>
          <p className="text-sm text-ink-500">
            Overall readiness score: <span className="font-semibold text-ink-800">{overallScore}</span>
            {profile.streak.count > 1 && (
              <span className="ml-2 text-orange-600">🔥 {profile.streak.count}-day streak</span>
            )}
          </p>
        </div>
        <div className="flex gap-2">
          <span className="w-fit rounded-full bg-xp-bg px-3 py-1.5 text-xs font-bold text-xp-text">
            ⚡ {profile.totalXp} XP
          </span>
          <Link
            href="/mistake-bank"
            className="w-fit rounded-full border border-ink-200 px-3.5 py-1.5 text-xs font-semibold text-ink-600 hover:bg-ink-50"
          >
            🧠 {profile.mistakeBank.length}
          </Link>
        </div>
      </div>

      <TodaysPractice focusDimension={focusDimension} recommendations={recommendations} />
      <SkillHeatmap profile={profile} />
      <DimensionHeatmap profile={profile} />

      {profile.certificates.length > 0 && (
        <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card">
          <h2 className="mb-3 text-base font-semibold text-ink-900">Certificates</h2>
          <div className="flex flex-wrap gap-2">
            {profile.certificates.map((c) => (
              <Link
                key={c.id}
                href={`/certificate/${c.skill}/${c.level}`}
                className="rounded-full border border-ink-200 px-3 py-1.5 text-xs font-medium text-ink-600 hover:bg-ink-50"
              >
                🏅 {SKILL_META[c.skill].label} · {c.level}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
