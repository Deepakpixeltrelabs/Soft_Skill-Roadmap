"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { SKILL_META, LEVEL_META } from "@/lib/constants";
import { Level, Skill, SKILLS, LEVELS } from "@/lib/types";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function CertificatePage() {
  const params = useParams<{ skill: string; level: string }>();
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState />;

  const skill = params.skill as Skill;
  const level = params.level as Level;

  if (!SKILLS.includes(skill) || !LEVELS.includes(level)) {
    return <div className="py-10 text-center text-sm text-ink-500">Invalid certificate.</div>;
  }

  const cert = [...profile.certificates].reverse().find((c) => c.skill === skill && c.level === level);
  const meta = SKILL_META[skill];

  if (!cert) {
    return (
      <div>
        <MobileHeader title="Certificate" />
        <div className="mx-auto max-w-md py-12 text-center">
          <div className="mb-3 text-4xl">🔒</div>
          <h1 className="mb-2 text-lg font-bold text-ink-900">Not earned yet</h1>
          <p className="mb-5 text-sm text-ink-500">
            Pass the {LEVEL_META[level].label} level assessment in {meta.label} to earn this certificate.
          </p>
          <Link
            href={`/assessment/level/${skill}/${level}`}
            className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
          >
            Take the assessment
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title="Certificate" />
      <div className="mx-auto max-w-lg">
        <div className="rounded-xl2 border-2 border-primary-200 bg-gradient-to-br from-primary-50 to-white p-8 text-center shadow-raised">
          <div className="mb-3 text-4xl">🏅</div>
          <div className="text-xs font-semibold uppercase tracking-widest text-primary-600">
            Starvizz Certification
          </div>
          <h1 className="mt-2 text-2xl font-bold text-ink-900">
            {meta.label} — {LEVEL_META[level].label}
          </h1>
          <p className="mt-2 text-sm text-ink-500">
            Awarded for demonstrating {LEVEL_META[level].label.toLowerCase()}-level competency in{" "}
            {meta.label.toLowerCase()}.
          </p>

          <div className="mx-auto my-6 h-px w-2/3 bg-ink-100" />

          <div className="flex justify-center gap-8 text-sm">
            <div>
              <div className="text-xs text-ink-400">Score</div>
              <div className="text-lg font-bold text-primary-700">{cert.score}</div>
            </div>
            <div>
              <div className="text-xs text-ink-400">Issued</div>
              <div className="text-lg font-bold text-ink-800">
                {new Date(cert.issuedDate).toLocaleDateString()}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 text-center">
          <Link href={`/roadmap/${skill}`} className="text-sm font-semibold text-primary-600 hover:underline">
            ← Back to {meta.label} roadmap
          </Link>
        </div>
      </div>
    </div>
  );
}
