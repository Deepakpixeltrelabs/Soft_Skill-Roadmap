"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { DIMENSION_META, LEVEL_DESCRIPTIONS, LEVEL_META, SKILL_DIMENSIONS, SKILL_META, XP, passThresholdFor } from "@/lib/constants";
import { getLevelAssessmentQuestions } from "@/lib/questionBank";
import { Level, LEVELS, Skill, SKILLS } from "@/lib/types";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function LevelDetailPage() {
  const params = useParams<{ skill: string; level: string }>();
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState />;

  const skill = params.skill as Skill;
  const level = params.level as Level;

  if (!SKILLS.includes(skill) || !LEVELS.includes(level)) {
    return <div className="py-10 text-center text-sm text-ink-500">Not found.</div>;
  }

  const skillMeta = SKILL_META[skill];
  const levelMeta = LEVEL_META[level];
  const state = profile.skills[skill];
  const isLocked = !state.unlockedLevels.includes(level);
  const dimensions = SKILL_DIMENSIONS[skill];
  const touchedCount = dimensions.filter((d) => state.touchedDimensions.includes(d)).length;
  const progressPct = dimensions.length ? Math.round((touchedCount / dimensions.length) * 100) : 0;
  const questionCount = getLevelAssessmentQuestions(skill, level).length;
  const threshold = passThresholdFor(level);
  const alreadyPassed = profile.levelAssessmentHistory.some(
    (r) => r.skill === skill && r.level === level && r.passed
  );

  if (isLocked) {
    return (
      <div>
        <MobileHeader title={levelMeta.label} subtitle={skillMeta.label} />
        <div className="mx-auto max-w-sm py-14 text-center">
          <div className="mb-3 text-4xl">🔒</div>
          <h1 className="mb-2 text-lg font-bold text-ink-900">Locked</h1>
          <p className="mb-5 text-sm text-ink-500">
            Complete the previous level's assessment to unlock {levelMeta.label}.
          </p>
          <Link
            href={`/roadmap/${skill}`}
            className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
          >
            Back to Learning Path
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title={levelMeta.label} subtitle={skillMeta.label} />

      {/* Hero */}
      <div className="mb-6 rounded-xl2 border border-mint-100 bg-mint-50 p-5 text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-white text-2xl shadow-card">
          {levelMeta.icon}
        </div>
        <h2 className="text-lg font-bold text-ink-900">{levelMeta.label}</h2>
        <p className="mx-auto mt-1 max-w-xs text-sm text-ink-500">{LEVEL_DESCRIPTIONS[skill][level]}</p>
        <div className="mx-auto mt-4 max-w-xs">
          <div className="mb-1 flex justify-between text-xs font-medium text-ink-500">
            <span>
              {touchedCount}/{dimensions.length} Modules
            </span>
            <span>{progressPct}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-white">
            <div className="h-full rounded-full bg-brand-500 transition-all" style={{ width: `${progressPct}%` }} />
          </div>
        </div>
      </div>

      {/* Modules */}
      <h3 className="mb-2 flex items-center gap-1.5 text-sm font-bold text-ink-900">📘 Modules</h3>
      <div className="mb-6 space-y-2.5">
        {dimensions.map((dim, i) => {
          const meta = DIMENSION_META[dim];
          const done = state.touchedDimensions.includes(dim);
          return (
            <Link
              key={dim}
              href={`/practice/${skill}/${level}?dimension=${dim}`}
              className="flex items-center gap-3 rounded-xl2 border border-ink-100 bg-white p-3.5 shadow-card transition-shadow hover:shadow-raised"
            >
              <span
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white ${
                  done ? "bg-mastered" : "bg-brand-500"
                }`}
              >
                {done ? "✓" : i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold text-ink-900">{meta.label}</div>
                <div className="truncate text-xs text-ink-400">{meta.description}</div>
                <div className="mt-1 flex items-center gap-2">
                  <span className="rounded-full bg-xp-bg px-2 py-0.5 text-[10px] font-bold text-xp-text">
                    +{XP.perModule} XP
                  </span>
                  <span className={`text-[11px] font-medium ${done ? "text-mastered" : "text-brand-600"}`}>
                    {done ? "● Completed" : "● Not started"}
                  </span>
                </div>
              </div>
              <span className="text-ink-300">›</span>
            </Link>
          );
        })}
      </div>

      {/* Capstone */}
      <h3 className="mb-2 flex items-center gap-1.5 text-sm font-bold text-ink-900">🏗️ Capstone Practice</h3>
      <Link
        href={`/practice/${skill}/${level}`}
        className="mb-6 block rounded-xl2 border border-ink-100 bg-white p-4 shadow-card transition-shadow hover:shadow-raised"
      >
        <div className="mb-2 flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-lg">
            {skillMeta.icon}
          </span>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">Capstone Practice</div>
            <div className="text-sm font-bold text-ink-900">Full {skillMeta.label} Mixed Practice</div>
          </div>
        </div>
        <p className="mb-3 text-xs text-ink-500">
          A combined activity covering every module above — the best way to check you're ready for the
          level assessment.
        </p>
        <div className="mb-1 text-[11px] text-ink-400">⏱ 10-15 minutes</div>
        <div className="flex flex-wrap gap-1.5">
          {dimensions.map((d) => (
            <span
              key={d}
              className="rounded-full bg-brand-50 px-2 py-0.5 text-[11px] font-medium text-brand-700"
            >
              {DIMENSION_META[d].label}
            </span>
          ))}
          <span className="rounded-full bg-xp-bg px-2 py-0.5 text-[11px] font-bold text-xp-text">
            +{XP.capstone} XP
          </span>
        </div>
      </Link>

      {/* Assessment */}
      <h3 className="mb-2 flex items-center gap-1.5 text-sm font-bold text-ink-900">📝 Assessment</h3>
      <div className="rounded-xl2 border border-ink-100 bg-white p-4 shadow-card">
        <div className="mb-3 flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary-50 text-lg">
            📝
          </span>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">Level Assessment</div>
            <div className="text-sm font-bold text-ink-900">Level Test{alreadyPassed ? " · Passed" : ""}</div>
          </div>
        </div>
        <div className="mb-4 flex flex-wrap gap-2 text-xs">
          <span className="rounded-full bg-ink-50 px-2.5 py-1 font-medium text-ink-600">❓ {questionCount} Questions</span>
          <span className="rounded-full bg-xp-bg px-2.5 py-1 font-bold text-xp-text">⚡ {XP.levelAssessmentPass} XP</span>
          <span className="rounded-full bg-mastered/10 px-2.5 py-1 font-medium text-mastered">✅ Pass at {threshold}%</span>
        </div>
        <Link
          href={`/assessment/level/${skill}/${level}`}
          className="block w-full rounded-full bg-primary-600 py-3 text-center text-sm font-bold text-white hover:bg-primary-700"
        >
          ▶ Start Assessment
        </Link>
      </div>
    </div>
  );
}
