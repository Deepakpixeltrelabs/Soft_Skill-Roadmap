"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { SKILL_META } from "@/lib/constants";
import { Skill, SKILLS } from "@/lib/types";
import ProgressionMap from "@/components/ProgressionMap";
import { ScorePill, StatusBadge } from "@/components/Badges";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function SkillRoadmapPage() {
  const params = useParams<{ skill: string }>();
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState />;

  const skill = params.skill as Skill;
  if (!SKILLS.includes(skill)) {
    return (
      <div className="py-10 text-center text-sm text-ink-500">
        Unknown skill.{" "}
        <Link href="/roadmap" className="text-brand-600 hover:underline">
          Back to roadmap
        </Link>
      </div>
    );
  }

  const state = profile.skills[skill];
  const meta = SKILL_META[skill];

  return (
    <div>
      <MobileHeader title="Learning Path" subtitle="Complete levels & master this skill" />

      <div className="mb-5 flex items-center justify-between rounded-xl2 border border-ink-100 bg-white p-4 shadow-card">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{meta.icon}</span>
          <div>
            <div className="text-base font-bold text-ink-900">{meta.label}</div>
            <div className="text-xs text-ink-400">{meta.description}</div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <ScorePill score={state.score} />
          <StatusBadge status={state.status} />
        </div>
      </div>

      <ProgressionMap skill={skill} currentLevel={state.level} unlockedLevels={state.unlockedLevels} />
    </div>
  );
}
