"use client";

import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { SKILL_META } from "@/lib/constants";
import { Skill, SKILLS } from "@/lib/types";
import { LevelBadge, ScorePill, StatusBadge } from "@/components/Badges";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function RoadmapOverviewPage() {
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState />;

  if (!profile.hasCompletedBaseline) {
    return (
      <div>
        <MobileHeader title="Roadmap" showBack={false} />
        <div className="mx-auto max-w-md py-12 text-center">
          <div className="mb-3 text-4xl">🗺️</div>
          <h1 className="mb-2 text-lg font-bold text-ink-900">No roadmap yet</h1>
          <p className="mb-5 text-sm text-ink-500">
            Complete the baseline assessment first so Starvizz can personalize your roadmap.
          </p>
          <Link
            href="/assessment/baseline"
            className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
          >
            Start Baseline Assessment
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title="Roadmap" subtitle="Foundation → Development → Professional → Mastery" showBack={false} />

      <div className="grid gap-3">
        {(SKILLS as Skill[]).map((skill) => {
          const state = profile.skills[skill];
          const meta = SKILL_META[skill];
          return (
            <Link
              key={skill}
              href={`/roadmap/${skill}`}
              className="rounded-xl2 border border-ink-100 bg-white p-4 shadow-card transition-shadow hover:shadow-raised"
            >
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{meta.icon}</span>
                  <span className="font-semibold text-ink-900">{meta.label}</span>
                </div>
                <LevelBadge level={state.level} />
              </div>
              <p className="mb-3 text-xs text-ink-400">{meta.description}</p>
              <div className="mb-2 h-2 w-full overflow-hidden rounded-full bg-ink-100">
                <div
                  className="h-full rounded-full"
                  style={{ width: `${state.score}%`, backgroundColor: meta.color }}
                />
              </div>
              <div className="flex items-center justify-between">
                <StatusBadge status={state.status} />
                <ScorePill score={state.score} />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
