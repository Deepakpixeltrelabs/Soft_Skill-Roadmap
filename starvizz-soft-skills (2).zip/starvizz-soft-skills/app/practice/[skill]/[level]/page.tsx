"use client";

import { Suspense, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import AssessmentRunner, { RunnerResult } from "@/components/AssessmentRunner";
import FeedbackReportView from "@/components/FeedbackReportView";
import { getQuestionsBySkillLevel, getQuestionsBySkillLevelDimension } from "@/lib/questionBank";
import { useProfile } from "@/lib/useProfile";
import { recordPracticeResult } from "@/lib/storage";
import { aggregateScores, aggregateDimensionScores } from "@/lib/mockAI";
import { DIMENSION_META, LEVEL_META, LEVELS, SKILL_META, XP } from "@/lib/constants";
import { Dimension, DIMENSIONS, Level, Skill, SKILLS } from "@/lib/types";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function PracticeSessionPage() {
  return (
    <Suspense fallback={<LoadingState />}>
      <PracticeSessionInner />
    </Suspense>
  );
}

function PracticeSessionInner() {
  const params = useParams<{ skill: string; level: string }>();
  const searchParams = useSearchParams();
  const { profile, isLoaded, setProfile } = useProfile();
  const [results, setResults] = useState<RunnerResult[] | null>(null);
  const [xpAwarded, setXpAwarded] = useState(0);

  if (!isLoaded || !profile) return <LoadingState />;

  const skill = params.skill as Skill;
  const level = params.level as Level;
  const dimensionParam = searchParams.get("dimension") as Dimension | null;
  const isModule = dimensionParam && DIMENSIONS.includes(dimensionParam);

  if (!SKILLS.includes(skill) || !LEVELS.includes(level)) {
    return <div className="py-10 text-center text-sm text-ink-500">Invalid practice session.</div>;
  }

  const questions = isModule
    ? getQuestionsBySkillLevelDimension(skill, level, dimensionParam!)
    : getQuestionsBySkillLevel(skill, level);
  const meta = SKILL_META[skill];
  const headerTitle = isModule ? DIMENSION_META[dimensionParam!].label : "Capstone Practice";

  function handleComplete(runnerResults: RunnerResult[]) {
    setResults(runnerResults);
    const avgScore = aggregateScores(runnerResults.map((r) => r.score));
    const dimensionScores = aggregateDimensionScores(
      runnerResults.map((r) => ({ question: r.question, score: r.score }))
    );
    const xp = isModule ? XP.perModule : XP.capstone;
    setXpAwarded(xp);

    const allMistakes = runnerResults.flatMap((r) => r.feedback.mistakes);
    const next = recordPracticeResult(profile!, skill, level, avgScore, allMistakes, dimensionScores, xp);
    setProfile(next);
  }

  if (questions.length === 0) {
    return (
      <div>
        <MobileHeader title={headerTitle} subtitle={`${meta.label} · ${LEVEL_META[level].label}`} />
        <div className="py-10 text-center text-sm text-ink-500">No practice content available yet.</div>
      </div>
    );
  }

  if (results) {
    const avgScore = aggregateScores(results.map((r) => r.score));
    return (
      <div>
        <MobileHeader title="Practice Complete" subtitle={`${meta.label} · ${LEVEL_META[level].label}`} />
        <div className="mx-auto max-w-xl">
          <div className="mb-5 text-center">
            <div className="mb-2 text-3xl">{avgScore >= 70 ? "🎉" : "💪"}</div>
            <h1 className="text-lg font-bold text-ink-900">Avg score {avgScore}</h1>
            <span className="mt-1 inline-block rounded-full bg-xp-bg px-3 py-1 text-xs font-bold text-xp-text">
              +{xpAwarded} XP earned
            </span>
          </div>

          <div className="space-y-4">
            {results.map((r) => (
              <FeedbackReportView key={r.question.id} question={r.question} feedback={r.feedback} />
            ))}
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link
              href={`/roadmap/${skill}/${level}`}
              className="rounded-full border border-ink-200 px-5 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
            >
              Back to {LEVEL_META[level].label}
            </Link>
            <Link
              href={`/assessment/level/${skill}/${level}`}
              className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
            >
              Take level assessment →
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title={headerTitle} subtitle={`${meta.label} · ${LEVEL_META[level].label}`} />
      <AssessmentRunner questions={questions} onComplete={handleComplete} submitLabel="See Feedback" />
    </div>
  );
}
