"use client";

import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { getTodaysPractice } from "@/lib/storage";
import { SKILL_META } from "@/lib/constants";
import { Skill, SKILLS } from "@/lib/types";
import { LevelBadge } from "@/components/Badges";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

export default function PracticeHubPage() {
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState />;

  if (!profile.hasCompletedBaseline) {
    return (
      <div>
        <MobileHeader title="Practice" showBack={false} />
        <div className="mx-auto max-w-md py-12 text-center">
          <div className="mb-3 text-4xl">⚡</div>
          <h1 className="mb-2 text-lg font-bold text-ink-900">Complete your baseline first</h1>
          <p className="mb-5 text-sm text-ink-500">
            Practice is personalized to your skill profile — take the baseline assessment to unlock it.
          </p>
          <Link
            href="/assessment/baseline"
            className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
          >
            Start Baseline Assessment
          </Link>
        </div>
      </div>
    );
  }

  const { recommendations } = getTodaysPractice(profile);
  const recommendedSet = new Set(recommendations.map((r) => r.skill));

  return (
    <div>
      <MobileHeader title="Practice" subtitle="Sharpen a skill ahead of your next level test" showBack={false} />

      <div className="space-y-3">
        {(SKILLS as Skill[]).map((skill) => {
          const state = profile.skills[skill];
          const meta = SKILL_META[skill];
          return (
            <Link
              key={skill}
              href={`/roadmap/${skill}/${state.level}`}
              className="flex items-center justify-between rounded-xl2 border border-ink-100 bg-white p-4 shadow-card transition-shadow hover:shadow-raised"
            >
              <div className="flex items-center gap-3">
                <span className="text-xl">{meta.icon}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-ink-900">{meta.label}</span>
                    {recommendedSet.has(skill) && (
                      <span className="rounded-full bg-brand-100 px-2 py-0.5 text-[10px] font-semibold text-brand-700">
                        Recommended
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-ink-400">Score: {state.score}</div>
                </div>
              </div>
              <LevelBadge level={state.level} />
            </Link>
          );
        })}
      </div>
    </div>
  );
}
