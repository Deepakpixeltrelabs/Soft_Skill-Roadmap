"use client";

import Link from "next/link";
import { useProfile } from "@/lib/useProfile";
import { DIMENSION_META, SKILL_META } from "@/lib/constants";
import MobileHeader from "@/components/MobileHeader";
import LoadingState from "@/components/LoadingState";

const REVISION_THRESHOLD = 3;

export default function MistakeBankPage() {
  const { profile, isLoaded } = useProfile();

  if (!isLoaded || !profile) return <LoadingState />;

  if (profile.mistakeBank.length === 0) {
    return (
      <div>
        <MobileHeader title="Improvement Bank" showBack={false} />
        <div className="mx-auto max-w-md py-12 text-center">
          <div className="mb-3 text-4xl">🧠</div>
          <h1 className="mb-2 text-lg font-bold text-ink-900">Your Improvement Bank is empty</h1>
          <p className="mb-5 text-sm text-ink-500">
            As you practice and take assessments, recurring mistakes will show up here so you can
            target them directly.
          </p>
          <Link
            href="/practice"
            className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-700"
          >
            Go to Practice
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <MobileHeader title="Improvement Bank" subtitle="Recurring mistakes, tracked across sessions" showBack={false} />

      <div className="space-y-3">
        {profile.mistakeBank.map((m) => {
          const skillMeta = SKILL_META[m.skill];
          const dimMeta = DIMENSION_META[m.dimension];
          const needsRevision = m.count >= REVISION_THRESHOLD;
          return (
            <div
              key={m.id}
              className={`rounded-xl2 border p-4 ${
                needsRevision ? "border-orange-200 bg-orange-50" : "border-ink-100 bg-white"
              } shadow-card`}
            >
              <div className="mb-2 flex items-center justify-between">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-sm font-semibold text-ink-900">{m.category}</span>
                  <span className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-medium text-ink-500">
                    {skillMeta.icon} {skillMeta.label}
                  </span>
                  <span className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-medium text-ink-500">
                    {dimMeta.icon} {dimMeta.label}
                  </span>
                </div>
                <span
                  className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-bold ${
                    needsRevision ? "bg-orange-200 text-orange-800" : "bg-ink-100 text-ink-600"
                  }`}
                >
                  {m.count}x
                </span>
              </div>
              <div className="mb-1 text-sm text-ink-700">
                <span className="text-developing">✗ "{m.example}"</span>
              </div>
              <div className="text-sm text-mastered">✓ "{m.correction}"</div>

              {needsRevision && (
                <div className="mt-3 flex items-center justify-between rounded-lg bg-white px-3 py-2">
                  <span className="text-xs font-medium text-orange-700">
                    Repeated {m.count} times — ready for smart revision
                  </span>
                  <Link
                    href={`/practice/${m.skill}/${profile.skills[m.skill].level}?dimension=${m.dimension}`}
                    className="text-xs font-semibold text-primary-600 hover:underline"
                  >
                    Practice now →
                  </Link>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
