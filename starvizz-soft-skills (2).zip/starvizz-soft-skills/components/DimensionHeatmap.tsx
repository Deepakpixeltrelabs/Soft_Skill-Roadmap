"use client";

import { useState } from "react";
import { DIMENSION_META } from "@/lib/constants";
import { Dimension, DIMENSIONS, UserProfile } from "@/lib/types";
import { ScorePill } from "./Badges";

export default function DimensionHeatmap({ profile }: { profile: UserProfile }) {
  const [expanded, setExpanded] = useState(false);
  const sorted = [...DIMENSIONS].sort((a, b) => profile.dimensions[a].score - profile.dimensions[b].score);
  const visible = expanded ? sorted : sorted.slice(0, 4);

  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card">
      <div className="mb-1 flex items-center justify-between">
        <h2 className="text-base font-semibold text-ink-900">Supporting Dimensions</h2>
        <button
          onClick={() => setExpanded((e) => !e)}
          className="text-xs font-semibold text-brand-600 hover:underline"
        >
          {expanded ? "Show less" : "Show all 11"}
        </button>
      </div>
      <p className="mb-4 text-xs text-ink-400">
        Measured inside every Listening, Speaking, Reading and Writing activity — not a separate track.
      </p>

      <div className="space-y-3">
        {visible.map((dim: Dimension) => {
          const state = profile.dimensions[dim];
          const meta = DIMENSION_META[dim];
          return (
            <div key={dim} className="flex items-center gap-3">
              <span className="w-6 shrink-0 text-center">{meta.icon}</span>
              <div className="w-32 shrink-0 truncate text-sm font-medium text-ink-800">{meta.label}</div>
              <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-ink-100">
                <div
                  className="h-full rounded-full bg-ink-500 transition-all"
                  style={{ width: `${state.score}%` }}
                />
              </div>
              <ScorePill score={state.score} />
            </div>
          );
        })}
      </div>
    </div>
  );
}
