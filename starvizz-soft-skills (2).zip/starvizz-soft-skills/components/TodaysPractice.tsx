import Link from "next/link";
import { DIMENSION_META, SKILL_META } from "@/lib/constants";
import { PracticeRecommendation } from "@/lib/storage";
import { Dimension } from "@/lib/types";
import { LevelBadge } from "./Badges";

export default function TodaysPractice({
  focusDimension,
  recommendations,
}: {
  focusDimension: Dimension | null;
  recommendations: PracticeRecommendation[];
}) {
  if (recommendations.length === 0) return null;

  const estMinutes = recommendations.length * 7;
  const focusMeta = focusDimension ? DIMENSION_META[focusDimension] : null;

  return (
    <div className="rounded-xl2 border border-brand-200 bg-brand-50 p-5">
      <div className="mb-1 flex items-center justify-between">
        <h2 className="text-base font-semibold text-brand-900">Today's Practice</h2>
        <span className="text-xs font-medium text-brand-700">~{estMinutes} min</span>
      </div>
      {focusMeta && (
        <p className="mb-4 text-sm text-brand-700">
          Today's focus: <span className="font-semibold">{focusMeta.icon} {focusMeta.label}</span> — practiced
          across the skills below.
        </p>
      )}

      <div className="space-y-2">
        {recommendations.map((rec) => {
          const meta = SKILL_META[rec.skill];
          return (
            <Link
              key={rec.skill}
              href={`/practice/${rec.skill}/${rec.level}`}
              className="flex items-center justify-between rounded-lg border border-brand-200 bg-white px-3 py-2.5 transition-shadow hover:shadow-card"
            >
              <div className="flex items-center gap-3">
                <span className="text-lg">{meta.icon}</span>
                <div>
                  <div className="text-sm font-semibold text-ink-900">{meta.label}</div>
                  <div className="text-xs text-ink-400">{rec.reason}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <LevelBadge level={rec.level} />
                <span className="text-brand-600">→</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
