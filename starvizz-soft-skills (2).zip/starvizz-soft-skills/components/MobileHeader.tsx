"use client";

import { useRouter } from "next/navigation";

export default function MobileHeader({
  title,
  subtitle,
  onBack,
  showBack = true,
  right,
}: {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  showBack?: boolean;
  right?: React.ReactNode;
}) {
  const router = useRouter();

  return (
    <div className="sticky top-0 z-30 -mx-4 mb-4 border-b border-mint-100 bg-mint-50 px-4 py-3 sm:-mx-6 sm:px-6">
      <div className="flex items-center gap-3">
        {showBack && (
          <button
            onClick={() => (onBack ? onBack() : router.back())}
            aria-label="Back"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/70 text-ink-700 hover:bg-white"
          >
            ←
          </button>
        )}
        <div className="min-w-0 flex-1 text-center">
          <h1 className="truncate text-base font-bold text-ink-900">{title}</h1>
          {subtitle && <p className="truncate text-xs text-ink-500">{subtitle}</p>}
        </div>
        <div className="w-8 shrink-0">{right}</div>
      </div>
    </div>
  );
}
