import Link from "next/link";
import { LEVELS, LEVEL_META, LEVEL_DESCRIPTIONS } from "@/lib/constants";
import { Level, Skill } from "@/lib/types";

type LevelState = "completed" | "current" | "locked";

function getLevelState(level: Level, currentLevel: Level, unlockedLevels: Level[]): LevelState {
  const order = LEVELS.indexOf(level);
  const currentOrder = LEVELS.indexOf(currentLevel);
  if (!unlockedLevels.includes(level)) return "locked";
  if (order < currentOrder) return "completed";
  if (level === currentLevel) return "current";
  return "locked";
}

/** "Learning Path" — floating island progression map, mirroring the app's existing visual language. */
export default function ProgressionMap({
  skill,
  currentLevel,
  unlockedLevels,
}: {
  skill: Skill;
  currentLevel: Level;
  unlockedLevels: Level[];
}) {
  // Render bottom-to-top like the reference app (first level at the bottom).
  const orderedLevels = [...LEVELS].reverse();

  return (
    <div className="relative py-2">
      <div
        className="absolute bottom-8 left-1/2 top-8 w-0.5 -translate-x-1/2 bg-repeat-y opacity-40"
        style={{
          backgroundImage:
            "repeating-linear-gradient(to bottom, #b0895a 0, #b0895a 6px, transparent 6px, transparent 12px)",
        }}
        aria-hidden
      />

      <div className="relative space-y-8">
        {orderedLevels.map((level, i) => {
          const state = getLevelState(level, currentLevel, unlockedLevels);
          const meta = LEVEL_META[level];
          const alignRight = i % 2 === 1;

          const islandNode = (
            <div
              className={`relative flex h-16 w-16 shrink-0 items-center justify-center rounded-[45%] text-2xl shadow-raised ${
                state === "locked"
                  ? "bg-gradient-to-b from-ink-200 to-ink-300"
                  : "bg-gradient-to-b from-brand-300 to-brand-600"
              }`}
            >
              <span className={state === "locked" ? "opacity-50 grayscale" : ""}>{meta.icon}</span>
              <span
                className={`absolute -top-1.5 -left-1.5 flex h-5 w-5 items-center justify-center rounded-full border-2 border-white text-[10px] font-bold text-white ${
                  state === "completed" ? "bg-mastered" : state === "current" ? "bg-primary-600" : "bg-ink-400"
                }`}
              >
                {state === "completed" ? "✓" : state === "locked" ? "🔒" : i + 1}
              </span>
            </div>
          );

          const callout = (
            <Link
              href={`/roadmap/${skill}/${level}`}
              className={`block flex-1 rounded-xl2 border bg-white px-3.5 py-2.5 shadow-card transition-shadow hover:shadow-raised ${
                state === "current" ? "border-primary-300" : state === "completed" ? "border-mastered/30" : "border-ink-100"
              } ${state === "locked" ? "opacity-70" : ""}`}
            >
              <div className="mb-0.5 text-sm font-bold text-ink-900">{meta.label}</div>
              <div className="line-clamp-2 text-xs text-ink-500">{LEVEL_DESCRIPTIONS[skill][level]}</div>
              {state === "current" && (
                <span className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-semibold text-primary-600">
                  ● In Progress
                </span>
              )}
              {state === "completed" && (
                <span className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-semibold text-mastered">
                  ✓ Completed
                </span>
              )}
              {state === "locked" && (
                <span className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-semibold text-ink-400">
                  🔒 Locked
                </span>
              )}
            </Link>
          );

          return (
            <div key={level} className={`flex items-center gap-3 ${alignRight ? "flex-row-reverse" : ""}`}>
              {islandNode}
              {callout}
            </div>
          );
        })}
      </div>
    </div>
  );
}
