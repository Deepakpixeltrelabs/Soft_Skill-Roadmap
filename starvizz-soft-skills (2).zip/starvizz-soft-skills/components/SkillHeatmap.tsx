import { SKILL_META } from "@/lib/constants";
import { Skill, UserProfile } from "@/lib/types";
import { LevelBadge, ScorePill } from "./Badges";
import Link from "next/link";

const SKILL_ORDER: Skill[] = ["listening", "speaking", "reading", "writing"];

export default function SkillHeatmap({ profile }: { profile: UserProfile }) {
  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-base font-semibold text-ink-900">Your Soft Skills Profile</h2>
        <Link href="/roadmap" className="text-xs font-semibold text-brand-600 hover:underline">
          View full roadmap →
        </Link>
      </div>

      <div className="space-y-3">
        {SKILL_ORDER.map((skill) => {
          const state = profile.skills[skill];
          const meta = SKILL_META[skill];
          return (
            <Link
              href={`/roadmap/${skill}`}
              key={skill}
              className="flex items-center gap-3 rounded-lg p-1.5 transition-colors hover:bg-ink-50"
            >
              <span className="w-7 shrink-0 text-center text-lg">{meta.icon}</span>
              <div className="w-24 shrink-0 text-sm font-medium text-ink-800">{meta.label}</div>
              <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-ink-100">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${state.score}%`, backgroundColor: meta.color }}
                />
              </div>
              <ScorePill score={state.score} />
              <div className="hidden w-24 shrink-0 text-right sm:block">
                <LevelBadge level={state.level} />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
