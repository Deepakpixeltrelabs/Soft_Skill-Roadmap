import { LEVEL_META, STATUS_META } from "@/lib/constants";
import { Level, SkillStatus } from "@/lib/types";

export function LevelBadge({ level }: { level: Level }) {
  const meta = LEVEL_META[level];
  return (
    <span className="inline-flex items-center rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-semibold text-ink-700">
      {meta.label}
    </span>
  );
}

export function StatusBadge({ status }: { status: SkillStatus }) {
  const meta = STATUS_META[status];
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-ink-50 px-2.5 py-0.5 text-xs font-semibold">
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      <span className={meta.color}>{meta.label}</span>
    </span>
  );
}

export function ScorePill({ score }: { score: number }) {
  const color =
    score >= 85 ? "bg-mastered/10 text-mastered" : score >= 60 ? "bg-proficient/10 text-proficient" : "bg-developing/10 text-developing";
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold ${color}`}>
      {score}
    </span>
  );
}
