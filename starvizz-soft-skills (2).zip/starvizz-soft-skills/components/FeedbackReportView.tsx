import { DIMENSION_META } from "@/lib/constants";
import { FeedbackReport, Question } from "@/lib/types";
import { ScorePill } from "./Badges";

const LAYER_ICONS = ["📝", "❌", "💡", "✅", "🔁"];

export default function FeedbackReportView({
  question,
  feedback,
}: {
  question: Question;
  feedback: FeedbackReport;
}) {
  const layers = [
    { title: "What you did", body: feedback.whatYouDid },
    { title: "What went wrong", body: feedback.whatWentWrong },
    { title: "Why it's wrong", body: feedback.whyItsWrong },
    { title: "How to improve", body: feedback.howToImprove },
    { title: "Practice again", body: feedback.practiceAgain },
  ];

  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card">
      <div className="mb-2 flex items-start justify-between gap-3">
        <p className="text-sm font-medium text-ink-800">{question.prompt}</p>
        <ScorePill score={feedback.score} />
      </div>

      <div className="mb-3 flex flex-wrap gap-1.5">
        {feedback.dimensions.map((d) => (
          <span key={d} className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-medium text-ink-500">
            {DIMENSION_META[d].icon} {DIMENSION_META[d].label}
          </span>
        ))}
      </div>

      {feedback.strengths.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-1.5">
          {feedback.strengths.map((s) => (
            <span
              key={s}
              className="rounded-full bg-mastered/10 px-2.5 py-0.5 text-xs font-medium text-mastered"
            >
              ✓ {s}
            </span>
          ))}
        </div>
      )}

      <div className="space-y-3">
        {layers.map((layer, i) => (
          <div key={layer.title} className="flex gap-3">
            <span className="mt-0.5 text-base leading-none">{LAYER_ICONS[i]}</span>
            <div>
              <div className="text-xs font-semibold uppercase tracking-wide text-ink-400">
                {layer.title}
              </div>
              <div className="text-sm text-ink-700">{layer.body}</div>
            </div>
          </div>
        ))}
      </div>

      {feedback.mistakes.length > 0 && (
        <div className="mt-4 rounded-lg bg-ink-50 p-3">
          <div className="mb-1.5 text-xs font-semibold text-ink-500">
            Dimension breakdown for this response
          </div>
          <ul className="space-y-1.5 text-xs text-ink-600">
            {feedback.mistakes.map((m) => (
              <li key={m.id} className="flex flex-wrap items-center gap-1.5">
                <span className="rounded-full bg-white px-1.5 py-0.5 text-[10px] font-semibold text-ink-500 ring-1 ring-inset ring-ink-200">
                  {DIMENSION_META[m.dimension].icon} {DIMENSION_META[m.dimension].label}
                </span>
                <span>
                  <span className="font-medium">{m.category}:</span> "{m.original}" → "{m.correction}"
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
