"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { href: "/", label: "Dashboard", icon: "🏠" },
  { href: "/roadmap", label: "Roadmap", icon: "🗺️" },
  { href: "/practice", label: "Practice", icon: "⚡", fab: true },
  { href: "/mistake-bank", label: "Mistakes", icon: "🧠" },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 mx-auto flex w-full max-w-md items-center justify-between border-t border-ink-100 bg-white px-3 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1.5 shadow-[0_-2px_12px_rgba(20,24,30,0.06)]">
      {TABS.map((tab) => {
        const active = tab.href === "/" ? pathname === "/" : pathname.startsWith(tab.href);

        if (tab.fab) {
          return (
            <Link
              key={tab.href}
              href={tab.href}
              className="flex flex-1 flex-col items-center gap-1"
            >
              <span
                className={`-mt-5 flex h-12 w-12 items-center justify-center rounded-full text-xl text-white shadow-raised transition-colors ${
                  active ? "bg-primary-600" : "bg-primary-500"
                }`}
              >
                {tab.icon}
              </span>
              <span className={`text-[10px] font-semibold ${active ? "text-primary-600" : "text-ink-400"}`}>
                {tab.label}
              </span>
            </Link>
          );
        }

        return (
          <Link
            key={tab.href}
            href={tab.href}
            className="flex flex-1 flex-col items-center gap-0.5 py-1.5"
          >
            <span className={`text-lg ${active ? "" : "opacity-60"}`}>{tab.icon}</span>
            <span className={`text-[10px] font-semibold ${active ? "text-brand-700" : "text-ink-400"}`}>
              {tab.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
