"use client";

import { useMemo, useState } from "react";
import { AnswerSubmission, FeedbackReport, Question } from "@/lib/types";
import { buildFeedbackReport, scoreSubmission } from "@/lib/mockAI";
import { DIMENSION_META, SKILL_META } from "@/lib/constants";

export interface RunnerResult {
  question: Question;
  submission: AnswerSubmission;
  feedback: FeedbackReport;
  score: number;
}

export default function AssessmentRunner({
  questions,
  onComplete,
  submitLabel = "Submit",
}: {
  questions: Question[];
  onComplete: (results: RunnerResult[]) => void;
  submitLabel?: string;
}) {
  const [index, setIndex] = useState(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | undefined>(undefined);
  const [textResponse, setTextResponse] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [results, setResults] = useState<RunnerResult[]>([]);

  const question = questions[index];
  const isLast = index === questions.length - 1;
  const meta = SKILL_META[question.skill];

  const canProceed = useMemo(() => {
    if (question.type === "writing" || question.type === "speaking") {
      return textResponse.trim().length > 0;
    }
    return !!selectedOptionId;
  }, [question.type, selectedOptionId, textResponse]);

  function handleNext() {
    const submission: AnswerSubmission = {
      questionId: question.id,
      skill: question.skill,
      type: question.type,
      selectedOptionId,
      textResponse,
    };
    const feedback = buildFeedbackReport(question, submission);
    const score = scoreSubmission(question, submission);
    const nextResults = [...results, { question, submission, feedback, score }];

    if (isLast) {
      onComplete(nextResults);
      return;
    }

    setResults(nextResults);
    setIndex(index + 1);
    setSelectedOptionId(undefined);
    setTextResponse("");
    setRevealed(false);
  }

  return (
    <div className="mx-auto max-w-xl">
      {/* progress */}
      <div className="mb-5">
        <div className="mb-1.5 flex items-center justify-between text-xs font-medium text-ink-400">
          <span>
            Question {index + 1} of {questions.length}
          </span>
          <span className="inline-flex items-center gap-1">
            {meta.icon} {meta.label}
          </span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
          <div
            className="h-full rounded-full bg-brand-600 transition-all"
            style={{ width: `${((index + 1) / questions.length) * 100}%` }}
          />
        </div>
        <div className="mt-2 flex flex-wrap gap-1">
          {question.dimensions.map((d) => (
            <span key={d} className="rounded-full bg-ink-50 px-2 py-0.5 text-[10px] font-medium text-ink-500">
              {DIMENSION_META[d].icon} {DIMENSION_META[d].label}
            </span>
          ))}
        </div>
      </div>

      <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card">
        {/* Reading passage */}
        {question.type === "reading" && question.passage && (
          <div className="mb-4 rounded-lg bg-ink-50 p-3.5 text-sm leading-relaxed text-ink-700">
            📖 {question.passage}
          </div>
        )}

        {/* Listening: simulated audio playback */}
        {question.type === "listening" && question.passage && (
          <div className="mb-4">
            {!revealed ? (
              <button
                onClick={() => setRevealed(true)}
                className="flex w-full items-center gap-3 rounded-lg border border-dashed border-ink-200 bg-ink-50 p-4 text-left transition-colors hover:bg-ink-100"
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white">
                  ▶
                </span>
                <div>
                  <div className="text-sm font-semibold text-ink-800">Play audio clip</div>
                  <div className="text-xs text-ink-400">Tap to listen (transcript shown for this demo)</div>
                </div>
              </button>
            ) : (
              <div className="rounded-lg bg-ink-50 p-3.5 text-sm leading-relaxed text-ink-700">
                🎧 <span className="italic">{question.passage}</span>
              </div>
            )}
          </div>
        )}

        <h3 className="mb-4 text-base font-semibold text-ink-900">{question.prompt}</h3>

        {(question.type === "mcq" || question.type === "reading" || question.type === "listening") &&
          (question.type !== "listening" || revealed) && (
            <div className="space-y-2">
              {question.options?.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSelectedOptionId(opt.id)}
                  className={`block w-full rounded-lg border px-3.5 py-2.5 text-left text-sm transition-colors ${
                    selectedOptionId === opt.id
                      ? "border-brand-500 bg-brand-50 font-medium text-brand-800"
                      : "border-ink-200 text-ink-700 hover:bg-ink-50"
                  }`}
                >
                  {opt.text}
                </button>
              ))}
            </div>
          )}

        {question.type === "listening" && !revealed && (
          <p className="text-sm text-ink-400">Play the audio above to see the answer options.</p>
        )}

        {(question.type === "writing" || question.type === "speaking") && (
          <div>
            {question.type === "speaking" && (
              <div className="mb-3 flex items-center gap-2 rounded-lg bg-orange-50 px-3 py-2 text-xs text-orange-700">
                🎙️ Type what you would say out loud — this simulates a speaking response for the demo.
              </div>
            )}
            <textarea
              value={textResponse}
              onChange={(e) => setTextResponse(e.target.value)}
              rows={5}
              placeholder={
                question.type === "speaking" ? "Type your spoken response here..." : "Write your response here..."
              }
              className="w-full resize-none rounded-lg border border-ink-200 p-3 text-sm text-ink-800 outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100"
            />
            {question.rubricHints && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {question.rubricHints.map((hint) => (
                  <span
                    key={hint}
                    className="rounded-full bg-ink-50 px-2 py-0.5 text-[11px] text-ink-500 ring-1 ring-inset ring-ink-100"
                  >
                    {hint}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-4 flex justify-end">
        <button
          onClick={handleNext}
          disabled={!canProceed}
          className="rounded-full bg-primary-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-primary-700 disabled:cursor-not-allowed disabled:bg-ink-200 disabled:text-ink-400"
        >
          {isLast ? submitLabel : "Next"}
        </button>
      </div>
    </div>
  );
}
